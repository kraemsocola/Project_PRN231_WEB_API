<!DOCTYPE html>
<html lang="en-US" prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# website: http://ogp.me/ns/website#">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes">
<title>Page not found &#8211; Chaai</title>
<meta name="robots" content="max-image-preview:large" />

<script data-cfasync="false" data-pagespeed-no-defer>//<![CDATA[
	var gtm4wp_datalayer_name = "dataLayer";
	var dataLayer = dataLayer || [];
//]]>
</script>
<link rel="dns-prefetch" href="//export.qodethemes.com" />
<link rel="dns-prefetch" href="//static.zdassets.com" />
<link rel="dns-prefetch" href="//fonts.googleapis.com" />
<link rel="alternate" type="application/rss+xml" title="Chaai &raquo; Feed" href="https://chaai.qodeinteractive.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Chaai &raquo; Comments Feed" href="https://chaai.qodeinteractive.com/comments/feed/" />
<script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/chaai.qodeinteractive.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.4.3"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83e\udef1\ud83c\udffb\u200d\ud83e\udef2\ud83c\udfff","\ud83e\udef1\ud83c\udffb\u200b\ud83e\udef2\ud83c\udfff")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<link rel="stylesheet" id="sb_instagram_styles-css" href="https://chaai.qodeinteractive.com/wp-content/plugins/instagram-feed/css/sbi-styles.min.css?ver=2.9.3.1" type="text/css" media="all" />
<link rel="stylesheet" id="dripicons-css" href="https://chaai.qodeinteractive.com/wp-content/plugins/chaai-core/inc/icons/dripicons/assets/css/dripicons.min.css?ver=6.4.3" type="text/css" media="all" />
<link rel="stylesheet" id="elegant-icons-css" href="https://chaai.qodeinteractive.com/wp-content/plugins/chaai-core/inc/icons/elegant-icons/assets/css/elegant-icons.min.css?ver=6.4.3" type="text/css" media="all" />
<link rel="stylesheet" id="font-awesome-css" href="https://chaai.qodeinteractive.com/wp-content/plugins/chaai-core/inc/icons/font-awesome/assets/css/all.min.css?ver=6.4.3" type="text/css" media="all" />
<link rel="stylesheet" id="fontkiko-css" href="https://chaai.qodeinteractive.com/wp-content/plugins/chaai-core/inc/icons/fontkiko/assets/css/kiko-all.min.css?ver=6.4.3" type="text/css" media="all" />
<link rel="stylesheet" id="ionicons-css" href="https://chaai.qodeinteractive.com/wp-content/plugins/chaai-core/inc/icons/ionicons/assets/css/ionicons.min.css?ver=6.4.3" type="text/css" media="all" />
<link rel="stylesheet" id="linea-icons-css" href="https://chaai.qodeinteractive.com/wp-content/plugins/chaai-core/inc/icons/linea-icons/assets/css/linea-icons.min.css?ver=6.4.3" type="text/css" media="all" />
<link rel="stylesheet" id="linear-icons-css" href="https://chaai.qodeinteractive.com/wp-content/plugins/chaai-core/inc/icons/linear-icons/assets/css/linear-icons.min.css?ver=6.4.3" type="text/css" media="all" />
<link rel="stylesheet" id="material-icons-css" href="https://fonts.googleapis.com/icon?family=Material+Icons&#038;ver=6.4.3" type="text/css" media="all" />
<link rel="stylesheet" id="simple-line-icons-css" href="https://chaai.qodeinteractive.com/wp-content/plugins/chaai-core/inc/icons/simple-line-icons/assets/css/simple-line-icons.min.css?ver=6.4.3" type="text/css" media="all" />
<style id="wp-emoji-styles-inline-css" type="text/css">

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel="stylesheet" id="wp-block-library-css" href="https://chaai.qodeinteractive.com/wp-includes/css/dist/block-library/style.min.css?ver=6.4.3" type="text/css" media="all" />
<link rel="stylesheet" id="wc-blocks-vendors-style-css" href="https://chaai.qodeinteractive.com/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-vendors-style.css?ver=5.9.1" type="text/css" media="all" />
<link rel="stylesheet" id="wc-blocks-style-css" href="https://chaai.qodeinteractive.com/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-style.css?ver=5.9.1" type="text/css" media="all" />
<style id="classic-theme-styles-inline-css" type="text/css">
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id="global-styles-inline-css" type="text/css">
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}body .is-layout-grid{display: grid;}body .is-layout-grid > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel="stylesheet" id="contact-form-7-css" href="https://chaai.qodeinteractive.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.5.1" type="text/css" media="all" />
<link rel="stylesheet" id="rabbit_css-css" href="https://export.qodethemes.com/_toolbar/assets/css/rbt-modules.css?ver=6.4.3" type="text/css" media="all" />
<style id="woocommerce-inline-inline-css" type="text/css">
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel="stylesheet" id="swiper-css" href="https://chaai.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/assets/plugins/swiper/swiper.min.css?ver=6.4.3" type="text/css" media="all" />
<link rel="stylesheet" id="qi-addons-for-elementor-grid-style-css" href="https://chaai.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/assets/css/grid.min.css?ver=6.4.3" type="text/css" media="all" />
<link rel="stylesheet" id="qi-addons-for-elementor-helper-parts-style-css" href="https://chaai.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/assets/css/helper-parts.min.css?ver=6.4.3" type="text/css" media="all" />
<link rel="stylesheet" id="qi-addons-for-elementor-style-css" href="https://chaai.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/assets/css/main.min.css?ver=6.4.3" type="text/css" media="all" />
<link rel="stylesheet" id="chaai-main-css" href="https://chaai.qodeinteractive.com/wp-content/themes/chaai/assets/css/main.min.css?ver=6.4.3" type="text/css" media="all" />
<link rel="stylesheet" id="chaai-core-style-css" href="https://chaai.qodeinteractive.com/wp-content/plugins/chaai-core/assets/css/chaai-core.min.css?ver=6.4.3" type="text/css" media="all" />
<link rel="stylesheet" id="chaai-google-fonts-css" href="https://fonts.googleapis.com/css?family=Cormorant+Garamond%3A300%2C400%2C400i%2C500%2C500i%2C600%2C700%7CEB+Garamond%3A300%2C400%2C400i%2C500%2C500i%2C600%2C700%7CSpectral%3A300%2C400%2C400i%2C500%2C500i%2C600%2C700%7CArimo%3A300%2C400%2C400i%2C500%2C500i%2C600%2C700&#038;subset=latin-ext&#038;display=swap&#038;ver=1.0.0" type="text/css" media="all" />
<link rel="stylesheet" id="chaai-grid-css" href="https://chaai.qodeinteractive.com/wp-content/themes/chaai/assets/css/grid.min.css?ver=6.4.3" type="text/css" media="all" />
<link rel="stylesheet" id="chaai-style-css" href="https://chaai.qodeinteractive.com/wp-content/themes/chaai/style.css?ver=6.4.3" type="text/css" media="all" />
<style id="chaai-style-inline-css" type="text/css">
#qodef-page-footer-bottom-area-inner { padding-top: 10px;padding-bottom: 10px;padding-left: 0px!important;padding-right: 0px!important;border-top-color: #c2cda4;border-top-width: 1px;border-top-style: solid;}body { background-color: #faf8f5;}#qodef-page-mobile-header .qodef-mobile-header-logo-link { height: 20px;}.qodef-header-navigation ul li.qodef-menu-item--narrow ul { background-color: #faf8f5;}.qodef-header-navigation ul li.qodef-menu-item--wide .qodef-drop-down-second { background-color: #faf8f5;}.qodef-page-title { background-image: url(https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/tittle-img.jpg);}.qodef-header--divided #qodef-page-header { height: 106px;}.qodef-mobile-header--standard #qodef-page-mobile-header-inner:not(.qodef-content-grid) { padding-left: 7%;padding-right: 7%;}.qodef-mobile-header--standard .qodef-mobile-header-navigation > ul:not(.qodef-content-grid) { padding-left: 7%;padding-right: 7%;}@media only screen and (max-width: 680px){h2, .qodef-h2 { font-size: 46px;}}
</style>
<link rel="stylesheet" id="qode-zendesk-chat-css" href="https://chaai.qodeinteractive.com/wp-content/plugins/qode-zendesk-chat//assets/main.css?ver=6.4.3" type="text/css" media="all" />
<script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-content/plugins/revslider/public/assets/js/rbtools.min.js?ver=6.5.8" async id="tp-tools-js"></script>
<script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-content/plugins/revslider/public/assets/js/rs6.min.js?ver=6.5.8" async id="revmin-js"></script>
<link rel="https://api.w.org/" href="https://chaai.qodeinteractive.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://chaai.qodeinteractive.com/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.4.3" />
<meta name="generator" content="WooCommerce 5.8.1" />


<meta property="og:site_name" content="Chaai" />
<meta property="og:url" content="https://chaai.qodeinteractive.com" />
<meta property="og:locale" content="en_US" />
<meta property="og:description" content="Organic Tea Shop Theme" />
<meta property="og:title" content="Chaai" />
<meta property="og:type" content="website" />
<meta property="og:image" content="https://chaai.qodeinteractive.com/wp-content/uploads/2021/10/chaai_open_graph.jpg" />
<meta property="og:image:width" content="1200" />
<meta property="og:image:height" content="630" />
<meta name="twitter:card" content="summary" />
<meta name="twitter:title" content="Chaai" />
<meta name="twitter:image" content="https://chaai.qodeinteractive.com/wp-content/uploads/2021/10/chaai_open_graph.jpg" />
<meta name="twitter:description" content="Organic Tea Shop Theme" />


<script data-cfasync="false" data-pagespeed-no-defer>//<![CDATA[
	var dataLayer_content = [];
	dataLayer.push( dataLayer_content );//]]>
</script>
<script data-cfasync="false">//<![CDATA[
(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.'+'js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-KLJLSX7');//]]>
</script>

 <noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
<meta name="generator" content="Powered by Slider Revolution 6.5.8 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<link rel="icon" href="https://chaai.qodeinteractive.com/wp-content/uploads/2021/10/cropped-fav_icon-32x32.png" sizes="32x32" />
<link rel="icon" href="https://chaai.qodeinteractive.com/wp-content/uploads/2021/10/cropped-fav_icon-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://chaai.qodeinteractive.com/wp-content/uploads/2021/10/cropped-fav_icon-180x180.png" />
<meta name="msapplication-TileImage" content="https://chaai.qodeinteractive.com/wp-content/uploads/2021/10/cropped-fav_icon-270x270.png" />
<script type="text/javascript">function setREVStartSize(e){
			//window.requestAnimationFrame(function() {				 
				window.RSIW = window.RSIW===undefined ? window.innerWidth : window.RSIW;	
				window.RSIH = window.RSIH===undefined ? window.innerHeight : window.RSIH;	
				try {								
					var pw = document.getElementById(e.c).parentNode.offsetWidth,
						newh;
					pw = pw===0 || isNaN(pw) ? window.RSIW : pw;
					e.tabw = e.tabw===undefined ? 0 : parseInt(e.tabw);
					e.thumbw = e.thumbw===undefined ? 0 : parseInt(e.thumbw);
					e.tabh = e.tabh===undefined ? 0 : parseInt(e.tabh);
					e.thumbh = e.thumbh===undefined ? 0 : parseInt(e.thumbh);
					e.tabhide = e.tabhide===undefined ? 0 : parseInt(e.tabhide);
					e.thumbhide = e.thumbhide===undefined ? 0 : parseInt(e.thumbhide);
					e.mh = e.mh===undefined || e.mh=="" || e.mh==="auto" ? 0 : parseInt(e.mh,0);		
					if(e.layout==="fullscreen" || e.l==="fullscreen") 						
						newh = Math.max(e.mh,window.RSIH);					
					else{					
						e.gw = Array.isArray(e.gw) ? e.gw : [e.gw];
						for (var i in e.rl) if (e.gw[i]===undefined || e.gw[i]===0) e.gw[i] = e.gw[i-1];					
						e.gh = e.el===undefined || e.el==="" || (Array.isArray(e.el) && e.el.length==0)? e.gh : e.el;
						e.gh = Array.isArray(e.gh) ? e.gh : [e.gh];
						for (var i in e.rl) if (e.gh[i]===undefined || e.gh[i]===0) e.gh[i] = e.gh[i-1];
											
						var nl = new Array(e.rl.length),
							ix = 0,						
							sl;					
						e.tabw = e.tabhide>=pw ? 0 : e.tabw;
						e.thumbw = e.thumbhide>=pw ? 0 : e.thumbw;
						e.tabh = e.tabhide>=pw ? 0 : e.tabh;
						e.thumbh = e.thumbhide>=pw ? 0 : e.thumbh;					
						for (var i in e.rl) nl[i] = e.rl[i]<window.RSIW ? 0 : e.rl[i];
						sl = nl[0];									
						for (var i in nl) if (sl>nl[i] && nl[i]>0) { sl = nl[i]; ix=i;}															
						var m = pw>(e.gw[ix]+e.tabw+e.thumbw) ? 1 : (pw-(e.tabw+e.thumbw)) / (e.gw[ix]);					
						newh =  (e.gh[ix] * m) + (e.tabh + e.thumbh);
					}
					var el = document.getElementById(e.c);
					if (el!==null && el) el.style.height = newh+"px";					
					el = document.getElementById(e.c+"_wrapper");
					if (el!==null && el) {
						el.style.height = newh+"px";
						el.style.display = "block";
					}
				} catch(e){
					console.log("Failure at Presize of Slider:" + e)
				}					   
			//});
		  };</script>
<style type="text/css" id="wp-custom-css">
			/* @media (min-width: 1025px) {
	.qodef-border-fix .swiper-wrapper {
		padding-left: 1px;
	}	
} */

	.qodef-border-fix .swiper-wrapper .qodef-e {
		padding: 1px;
	}			</style>
</head>
<body class="error404 theme-chaai qode-framework-1.1.6 woocommerce-no-js qodef-qi--no-touch qi-addons-for-elementor-1.5 qodef-back-to-top--enabled  qodef-top-slider--disabled qodef-header--divided qodef-header-appearance--sticky qodef-mobile-header--standard qodef-drop-down-second--full-width qodef-drop-down-second--default qodef-yith-wccl--predefined qodef-yith-wcqv--predefined qodef-yith-wcwl--predefined chaai-core-1.0 chaai-1.0 qodef-content-grid-1300 qodef-search--covers-header elementor-default elementor-kit-7" itemscope itemtype="https://schema.org/WebPage">
<a class="skip-link screen-reader-text" href="#qodef-page-content">Skip to the content</a> <div id="qodef-page-wrapper" class>
<header id="qodef-page-header" role="banner">
<div id="qodef-page-header-inner" class>
<div class="qodef-divided-header-left-wrapper">
<nav class="qodef-header-navigation" role="navigation" aria-label="Divided Left Menu">
<ul id="menu-divided-left" class="menu"><li id="menu-item-1213" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1213 qodef-menu-item--narrow"><a href="#"><span class="qodef-menu-item-text">Home<svg class="qodef-svg--menu-arrow qodef-menu-item-arrow" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="12" height="8" viewBox="0 0 12.09 8.5" enable-background="new 0 0 12.09 8.5" xml:space="preserve"><g><path d="M11.98,4.02c0.06,0.06,0.09,0.14,0.09,0.23c0,0.09-0.03,0.17-0.09,0.23l-3.9,3.9C8.05,8.41,8.02,8.44,7.97,8.45
            C7.94,8.47,7.89,8.48,7.85,8.48S7.77,8.47,7.73,8.45C7.69,8.44,7.65,8.41,7.62,8.38c-0.06-0.06-0.1-0.14-0.1-0.23
            s0.03-0.17,0.1-0.23l3.35-3.35H0.38c-0.09,0-0.17-0.03-0.23-0.09s-0.1-0.14-0.1-0.23c0-0.09,0.03-0.17,0.1-0.24
            c0.06-0.06,0.14-0.09,0.23-0.09h10.59L7.62,0.58c-0.06-0.06-0.1-0.14-0.1-0.23s0.03-0.17,0.1-0.23c0.06-0.06,0.14-0.1,0.23-0.1
            c0.09,0,0.16,0.03,0.23,0.1L11.98,4.02z" /></g></svg></span></a>
<div class="qodef-drop-down-second"><div class="qodef-drop-down-second-inner"><ul class="sub-menu">
<li id="menu-item-1214" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-1214"><a href="https://chaai.qodeinteractive.com/"><span class="qodef-menu-item-text">Main Home</span></a></li>
<li id="menu-item-1215" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1215"><a href="https://chaai.qodeinteractive.com/tea-shop/"><span class="qodef-menu-item-text">Tea Shop</span></a></li>
<li id="menu-item-1216" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1216"><a href="https://chaai.qodeinteractive.com/tea-house/"><span class="qodef-menu-item-text">Tea House</span></a></li>
<li id="menu-item-1502" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1502"><a href="https://chaai.qodeinteractive.com/landing/"><span class="qodef-menu-item-text">Landing</span></a></li>
</ul></div></div>
</li>
<li id="menu-item-1217" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1217 qodef-menu-item--narrow"><a href="#"><span class="qodef-menu-item-text">Pages<svg class="qodef-svg--menu-arrow qodef-menu-item-arrow" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="12" height="8" viewBox="0 0 12.09 8.5" enable-background="new 0 0 12.09 8.5" xml:space="preserve"><g><path d="M11.98,4.02c0.06,0.06,0.09,0.14,0.09,0.23c0,0.09-0.03,0.17-0.09,0.23l-3.9,3.9C8.05,8.41,8.02,8.44,7.97,8.45
            C7.94,8.47,7.89,8.48,7.85,8.48S7.77,8.47,7.73,8.45C7.69,8.44,7.65,8.41,7.62,8.38c-0.06-0.06-0.1-0.14-0.1-0.23
            s0.03-0.17,0.1-0.23l3.35-3.35H0.38c-0.09,0-0.17-0.03-0.23-0.09s-0.1-0.14-0.1-0.23c0-0.09,0.03-0.17,0.1-0.24
            c0.06-0.06,0.14-0.09,0.23-0.09h10.59L7.62,0.58c-0.06-0.06-0.1-0.14-0.1-0.23s0.03-0.17,0.1-0.23c0.06-0.06,0.14-0.1,0.23-0.1
            c0.09,0,0.16,0.03,0.23,0.1L11.98,4.02z" /></g></svg></span></a>
<div class="qodef-drop-down-second"><div class="qodef-drop-down-second-inner"><ul class="sub-menu">
<li id="menu-item-1218" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1218"><a href="https://chaai.qodeinteractive.com/about-us/"><span class="qodef-menu-item-text">About Us</span></a></li>
<li id="menu-item-1222" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1222"><a href="https://chaai.qodeinteractive.com/our-team/"><span class="qodef-menu-item-text">Our Team</span></a></li>
<li id="menu-item-1221" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1221"><a href="https://chaai.qodeinteractive.com/our-menu/"><span class="qodef-menu-item-text">Our Menu</span></a></li>
<li id="menu-item-1219" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1219"><a href="https://chaai.qodeinteractive.com/booking-page/"><span class="qodef-menu-item-text">Booking</span></a></li>
<li id="menu-item-1220" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1220"><a href="https://chaai.qodeinteractive.com/our-location/"><span class="qodef-menu-item-text">Our Location</span></a></li>
<li id="menu-item-1538" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1538"><a href="https://chaai.qodeinteractive.com/contact-us/"><span class="qodef-menu-item-text">Contact Us</span></a></li>
</ul></div></div>
</li>
<li id="menu-item-1223" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1223 qodef-menu-item--narrow"><a href="#"><span class="qodef-menu-item-text">Shop<svg class="qodef-svg--menu-arrow qodef-menu-item-arrow" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="12" height="8" viewBox="0 0 12.09 8.5" enable-background="new 0 0 12.09 8.5" xml:space="preserve"><g><path d="M11.98,4.02c0.06,0.06,0.09,0.14,0.09,0.23c0,0.09-0.03,0.17-0.09,0.23l-3.9,3.9C8.05,8.41,8.02,8.44,7.97,8.45
            C7.94,8.47,7.89,8.48,7.85,8.48S7.77,8.47,7.73,8.45C7.69,8.44,7.65,8.41,7.62,8.38c-0.06-0.06-0.1-0.14-0.1-0.23
            s0.03-0.17,0.1-0.23l3.35-3.35H0.38c-0.09,0-0.17-0.03-0.23-0.09s-0.1-0.14-0.1-0.23c0-0.09,0.03-0.17,0.1-0.24
            c0.06-0.06,0.14-0.09,0.23-0.09h10.59L7.62,0.58c-0.06-0.06-0.1-0.14-0.1-0.23s0.03-0.17,0.1-0.23c0.06-0.06,0.14-0.1,0.23-0.1
            c0.09,0,0.16,0.03,0.23,0.1L11.98,4.02z" /></g></svg></span></a>
<div class="qodef-drop-down-second"><div class="qodef-drop-down-second-inner"><ul class="sub-menu">
<li id="menu-item-1225" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1225"><a href="https://chaai.qodeinteractive.com/shop/"><span class="qodef-menu-item-text">Shop List</span></a></li>
<li id="menu-item-1229" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-1229"><a href="https://chaai.qodeinteractive.com/product/bouquet/"><span class="qodef-menu-item-text">Shop Single</span></a></li>
<li id="menu-item-2827" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2827"><a href="https://chaai.qodeinteractive.com/shop/shop-slider/"><span class="qodef-menu-item-text">Shop Slider</span></a></li>
<li id="menu-item-1233" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1233"><a href="#"><span class="qodef-menu-item-text">Shop Layouts<svg class="qodef-svg--menu-arrow qodef-menu-item-arrow" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="12" height="8" viewBox="0 0 12.09 8.5" enable-background="new 0 0 12.09 8.5" xml:space="preserve"><g><path d="M11.98,4.02c0.06,0.06,0.09,0.14,0.09,0.23c0,0.09-0.03,0.17-0.09,0.23l-3.9,3.9C8.05,8.41,8.02,8.44,7.97,8.45
            C7.94,8.47,7.89,8.48,7.85,8.48S7.77,8.47,7.73,8.45C7.69,8.44,7.65,8.41,7.62,8.38c-0.06-0.06-0.1-0.14-0.1-0.23
            s0.03-0.17,0.1-0.23l3.35-3.35H0.38c-0.09,0-0.17-0.03-0.23-0.09s-0.1-0.14-0.1-0.23c0-0.09,0.03-0.17,0.1-0.24
            c0.06-0.06,0.14-0.09,0.23-0.09h10.59L7.62,0.58c-0.06-0.06-0.1-0.14-0.1-0.23s0.03-0.17,0.1-0.23c0.06-0.06,0.14-0.1,0.23-0.1
            c0.09,0,0.16,0.03,0.23,0.1L11.98,4.02z" /></g></svg></span></a>
<ul class="sub-menu">
<li id="menu-item-1234" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1234"><a href="https://chaai.qodeinteractive.com/shop/three-columns/"><span class="qodef-menu-item-text">Three Columns</span></a></li>
<li id="menu-item-1235" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1235"><a href="https://chaai.qodeinteractive.com/shop/three-columns-wide/"><span class="qodef-menu-item-text">Three Columns Wide</span></a></li>
<li id="menu-item-1236" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1236"><a href="https://chaai.qodeinteractive.com/shop/four-columns/"><span class="qodef-menu-item-text">Four Columns</span></a></li>
<li id="menu-item-1237" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1237"><a href="https://chaai.qodeinteractive.com/shop/four-columns-wide/"><span class="qodef-menu-item-text">Four Columns Wide</span></a></li>
<li id="menu-item-1238" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1238"><a href="https://chaai.qodeinteractive.com/shop/five-columns-wide/"><span class="qodef-menu-item-text">Five Columns Wide</span></a></li>
</ul>
</li>
<li id="menu-item-1266" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1266 qodef--hide-link"><a href="#" onclick="JavaScript: return false;"><span class="qodef-menu-item-text">Shop Pages<svg class="qodef-svg--menu-arrow qodef-menu-item-arrow" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="12" height="8" viewBox="0 0 12.09 8.5" enable-background="new 0 0 12.09 8.5" xml:space="preserve"><g><path d="M11.98,4.02c0.06,0.06,0.09,0.14,0.09,0.23c0,0.09-0.03,0.17-0.09,0.23l-3.9,3.9C8.05,8.41,8.02,8.44,7.97,8.45
            C7.94,8.47,7.89,8.48,7.85,8.48S7.77,8.47,7.73,8.45C7.69,8.44,7.65,8.41,7.62,8.38c-0.06-0.06-0.1-0.14-0.1-0.23
            s0.03-0.17,0.1-0.23l3.35-3.35H0.38c-0.09,0-0.17-0.03-0.23-0.09s-0.1-0.14-0.1-0.23c0-0.09,0.03-0.17,0.1-0.24
            c0.06-0.06,0.14-0.09,0.23-0.09h10.59L7.62,0.58c-0.06-0.06-0.1-0.14-0.1-0.23s0.03-0.17,0.1-0.23c0.06-0.06,0.14-0.1,0.23-0.1
            c0.09,0,0.16,0.03,0.23,0.1L11.98,4.02z" /></g></svg></span></a>
<ul class="sub-menu">
<li id="menu-item-1265" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1265"><a href="https://chaai.qodeinteractive.com/my-account/"><span class="qodef-menu-item-text">My Account</span></a></li>
<li id="menu-item-1263" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1263"><a href="https://chaai.qodeinteractive.com/cart/"><span class="qodef-menu-item-text">Cart</span></a></li>
<li id="menu-item-1264" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1264"><a href="https://chaai.qodeinteractive.com/checkout/"><span class="qodef-menu-item-text">Checkout</span></a></li>
</ul>
</li>
</ul></div></div>
</li>
<li id="menu-item-1240" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1240 qodef-menu-item--narrow"><a href="#"><span class="qodef-menu-item-text">Blog<svg class="qodef-svg--menu-arrow qodef-menu-item-arrow" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="12" height="8" viewBox="0 0 12.09 8.5" enable-background="new 0 0 12.09 8.5" xml:space="preserve"><g><path d="M11.98,4.02c0.06,0.06,0.09,0.14,0.09,0.23c0,0.09-0.03,0.17-0.09,0.23l-3.9,3.9C8.05,8.41,8.02,8.44,7.97,8.45
            C7.94,8.47,7.89,8.48,7.85,8.48S7.77,8.47,7.73,8.45C7.69,8.44,7.65,8.41,7.62,8.38c-0.06-0.06-0.1-0.14-0.1-0.23
            s0.03-0.17,0.1-0.23l3.35-3.35H0.38c-0.09,0-0.17-0.03-0.23-0.09s-0.1-0.14-0.1-0.23c0-0.09,0.03-0.17,0.1-0.24
            c0.06-0.06,0.14-0.09,0.23-0.09h10.59L7.62,0.58c-0.06-0.06-0.1-0.14-0.1-0.23s0.03-0.17,0.1-0.23c0.06-0.06,0.14-0.1,0.23-0.1
            c0.09,0,0.16,0.03,0.23,0.1L11.98,4.02z" /></g></svg></span></a>
<div class="qodef-drop-down-second"><div class="qodef-drop-down-second-inner"><ul class="sub-menu">
<li id="menu-item-1241" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1241"><a href="https://chaai.qodeinteractive.com/blog-standard/"><span class="qodef-menu-item-text">Blog Right Sidebar</span></a></li>
<li id="menu-item-1242" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1242"><a href="https://chaai.qodeinteractive.com/blog-left-sidebar/"><span class="qodef-menu-item-text">Blog Left Sidebar</span></a></li>
<li id="menu-item-1243" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1243"><a href="https://chaai.qodeinteractive.com/blog-no-sidebar/"><span class="qodef-menu-item-text">Blog No Sidebar</span></a></li>
<li id="menu-item-3040" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3040"><a href="https://chaai.qodeinteractive.com/blog-slider/"><span class="qodef-menu-item-text">Blog Slider</span></a></li>
<li id="menu-item-1244" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1244"><a href="https://chaai.qodeinteractive.com/pinterest-blog-list/"><span class="qodef-menu-item-text">Blog Pinterest</span></a></li>
<li id="menu-item-1245" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1245"><a href="#"><span class="qodef-menu-item-text">Post Types<svg class="qodef-svg--menu-arrow qodef-menu-item-arrow" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="12" height="8" viewBox="0 0 12.09 8.5" enable-background="new 0 0 12.09 8.5" xml:space="preserve"><g><path d="M11.98,4.02c0.06,0.06,0.09,0.14,0.09,0.23c0,0.09-0.03,0.17-0.09,0.23l-3.9,3.9C8.05,8.41,8.02,8.44,7.97,8.45
            C7.94,8.47,7.89,8.48,7.85,8.48S7.77,8.47,7.73,8.45C7.69,8.44,7.65,8.41,7.62,8.38c-0.06-0.06-0.1-0.14-0.1-0.23
            s0.03-0.17,0.1-0.23l3.35-3.35H0.38c-0.09,0-0.17-0.03-0.23-0.09s-0.1-0.14-0.1-0.23c0-0.09,0.03-0.17,0.1-0.24
            c0.06-0.06,0.14-0.09,0.23-0.09h10.59L7.62,0.58c-0.06-0.06-0.1-0.14-0.1-0.23s0.03-0.17,0.1-0.23c0.06-0.06,0.14-0.1,0.23-0.1
            c0.09,0,0.16,0.03,0.23,0.1L11.98,4.02z" /></g></svg></span></a>
<ul class="sub-menu">
<li id="menu-item-1246" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1246"><a href="https://chaai.qodeinteractive.com/popular-tea-shops-in-japan/"><span class="qodef-menu-item-text">Standard Post</span></a></li>
<li id="menu-item-1247" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1247"><a href="https://chaai.qodeinteractive.com/everyday-tea/"><span class="qodef-menu-item-text">Link Post</span></a></li>
<li id="menu-item-1248" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1248"><a href="https://chaai.qodeinteractive.com/tea-world/"><span class="qodef-menu-item-text">Quote Post</span></a></li>
<li id="menu-item-1249" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1249"><a href="https://chaai.qodeinteractive.com/enjoy-every-moment/"><span class="qodef-menu-item-text">Audio Post</span></a></li>
<li id="menu-item-1250" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1250"><a href="https://chaai.qodeinteractive.com/fantastic-taste-of-tea-flavor/"><span class="qodef-menu-item-text">Galery Post</span></a></li>
<li id="menu-item-1251" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1251"><a href="https://chaai.qodeinteractive.com/learn-more-about-tea/"><span class="qodef-menu-item-text">Video Post</span></a></li>
<li id="menu-item-2828" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-2828"><a href="https://chaai.qodeinteractive.com/inspiration-in-tea/"><span class="qodef-menu-item-text">No Sidebar Post</span></a></li>
</ul>
</li>
</ul></div></div>
</li>
</ul> </nav>
</div>
<a itemprop="url" class="qodef-header-logo-link qodef-height--not-set qodef-source--image" href="https://chaai.qodeinteractive.com/" rel="home">
<img width="260" height="56" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/10/chaai-home-2-logo1.png" class="qodef-header-logo-image qodef--main" alt="logo main" itemprop="image" /><img width="260" height="56" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/10/chaai-home-2-logo1.png" class="qodef-header-logo-image qodef--dark" alt="logo dark" itemprop="image" /><img width="288" height="212" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/10/chaai-logo-light-img.png" class="qodef-header-logo-image qodef--light" alt="logo light" itemprop="image" /></a>
<div class="qodef-divided-header-right-wrapper">
<div class="qodef-widget-holder qodef--one">
<div id="chaai_core_woo_side_area_cart-2" class="widget widget_chaai_core_woo_side_area_cart qodef-header-widget-area-one" data-area="header-widget-one"> <div class="qodef-widget-side-area-cart-inner">
<a itemprop="url" class="qodef-m-opener" href="https://chaai.qodeinteractive.com/cart/">
<span class="qodef-m-opener-icon">
<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="16" height="21" viewBox="0 0 16.92 21.42" enable-background="new 0 0 16.92 21.42" xml:space="preserve">
<g>
<path fill="none" stroke-width="1.15" stroke-linecap="round" stroke-miterlimit="10" d="M5,4.98l0.02-0.76
                    c0-1.92,1.56-3.48,3.48-3.48l0,0c1.92,0,3.48,1.56,3.48,3.48l-0.02,0.76" />
<path fill="none" stroke-width="1.15" stroke-linejoin="round" stroke-miterlimit="10" d="M15.5,5.92l0.77,13.91
                    c0.03,0.5-0.37,0.92-0.87,0.92H1.59c-0.5,0-0.9-0.42-0.87-0.92L1.5,5.92C1.52,5.46,1.9,5.1,2.37,5.1h12.27
                    C15.1,5.1,15.48,5.46,15.5,5.92z" />
</g>
</svg>
</span>
<span class="qodef-m-opener-count">(50)</span>
</a>
<div class="qodef-widget-side-area-cart-content">
<ul class="qodef-woo-side-area-cart">
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=13f3cf8c531952d72e5847c4183e6910&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="443" data-cart_item_key="13f3cf8c531952d72e5847c4183e6910" data-product_sku="010"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/fruit-tea/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/fruit-tea/">Fruit Tea</a> </h6>
<p class="qodef-e-quantity">Quantity: 1</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>39.09</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=ab817c9349cf9c4f6877e1894a1faa00&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="467" data-cart_item_key="ab817c9349cf9c4f6877e1894a1faa00" data-product_sku="012"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/exotic-tea/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/exotic-tea/">Exotic Tea</a> </h6>
<p class="qodef-e-quantity">Quantity: 2</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>26.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=dc6a6489640ca02b0d42dabeb8e46bb7&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="469" data-cart_item_key="dc6a6489640ca02b0d42dabeb8e46bb7" data-product_sku="013"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/white-peony/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/white-peony/">White Peony</a> </h6>
<p class="qodef-e-quantity">Quantity: 2</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>37.05</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=43dd49b4fdb9bede653e94468ff8df1e&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1066" data-cart_item_key="43dd49b4fdb9bede653e94468ff8df1e" data-product_sku="020"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/liberty-tea/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/liberty-tea/">Liberty Tea</a> </h6>
<p class="qodef-e-quantity">Quantity: 1</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>37.05</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=53adaf494dc89ef7196d73636eb2451b&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1068" data-cart_item_key="53adaf494dc89ef7196d73636eb2451b" data-product_sku="021"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/golden-elixir/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/golden-elixir/">Golden Elixir</a> </h6>
<p class="qodef-e-quantity">Quantity: 2</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>20.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=1b0114c51cc532ed34e1954b5b9e4b58&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1071" data-cart_item_key="1b0114c51cc532ed34e1954b5b9e4b58" data-product_sku="022"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/hibiscus/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/hibiscus/">Hibiscus</a> </h6>
<p class="qodef-e-quantity">Quantity: 2</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>29.05</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=390e982518a50e280d8e2b535462ec1f&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1073" data-cart_item_key="390e982518a50e280d8e2b535462ec1f" data-product_sku="023"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/china-chai/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/china-chai/">China Chai</a> </h6>
<p class="qodef-e-quantity">Quantity: 1</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>27.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=4a08142c38dbe374195d41c04562d9f8&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1059" data-cart_item_key="4a08142c38dbe374195d41c04562d9f8" data-product_sku="018"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/rooibos/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/rooibos/">Rooibos</a> </h6>
<p class="qodef-e-quantity">Quantity: 3</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>37.05</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=27ed0fb950b856b06e1273989422e7d3&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1039" data-cart_item_key="27ed0fb950b856b06e1273989422e7d3" data-product_sku="014"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/bouquet/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/bouquet/">Bouquet</a> </h6>
<p class="qodef-e-quantity">Quantity: 1</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>25.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=7cce53cf90577442771720a370c3c723&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1048" data-cart_item_key="7cce53cf90577442771720a370c3c723" data-product_sku="016"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/rou-gui/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/rou-gui/">Rou Gui</a> </h6>
<p class="qodef-e-quantity">Quantity: 3</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>39.09</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=5055cbf43fac3f7e2336b27310f0b9ef&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1050" data-cart_item_key="5055cbf43fac3f7e2336b27310f0b9ef" data-product_sku="017"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/masala-chai/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img5-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img5-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img5-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img5-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img5-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img5.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/masala-chai/">Masala Chai</a> </h6>
<p class="qodef-e-quantity">Quantity: 1</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>330.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=a0e2a2c563d57df27213ede1ac4ac780&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1045" data-cart_item_key="a0e2a2c563d57df27213ede1ac4ac780" data-product_sku="015"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/yellow-bud/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/yellow-bud/">Yellow Bud</a> </h6>
<p class="qodef-e-quantity">Quantity: 2</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>20.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=6faa8040da20ef399b63a72d0e4ab575&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="329" data-cart_item_key="6faa8040da20ef399b63a72d0e4ab575" data-product_sku="01"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/sage/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/sage/">Sage</a> </h6>
<p class="qodef-e-quantity">Quantity: 2</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>25.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=bbcbff5c1f1ded46c25d28119a85c6c2&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="405" data-cart_item_key="bbcbff5c1f1ded46c25d28119a85c6c2" data-product_sku="02"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/chamomile/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/chamomile/">Chamomile</a> </h6>
<p class="qodef-e-quantity">Quantity: 3</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>20.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=f4f6dce2f3a0f9dada0c2b5b66452017&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="407" data-cart_item_key="f4f6dce2f3a0f9dada0c2b5b66452017" data-product_sku="03"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/motherwort/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/motherwort/">Motherwort</a> </h6>
<p class="qodef-e-quantity">Quantity: 2</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>27.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=a96b65a721e561e1e3de768ac819ffbb&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="409" data-cart_item_key="a96b65a721e561e1e3de768ac819ffbb" data-product_sku="04"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/oriental-mix/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/oriental-mix/">Oriental Mix</a> </h6>
<p class="qodef-e-quantity">Quantity: 4</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>30.09</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=faa9afea49ef2ff029a833cccc778fd0&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="423" data-cart_item_key="faa9afea49ef2ff029a833cccc778fd0" data-product_sku="06"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/yunnan-tea/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img9-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img9-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img9-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img9-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img9-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img9.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/yunnan-tea/">Yunnan Tea</a> </h6>
<p class="qodef-e-quantity">Quantity: 4</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>23.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=25b2822c2f5a3230abfadd476e8b04c9&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="425" data-cart_item_key="25b2822c2f5a3230abfadd476e8b04c9" data-product_sku="07"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/sunset-ice/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/sunset-ice/">Sunset Ice</a> </h6>
<p class="qodef-e-quantity">Quantity: 4</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>27.05</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=18997733ec258a9fcaf239cc55d53363&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="427" data-cart_item_key="18997733ec258a9fcaf239cc55d53363" data-product_sku="08"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/phoenix-eyes/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/phoenix-eyes/">Phoenix Eyes</a> </h6>
<p class="qodef-e-quantity">Quantity: 4</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>29.05</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=f74909ace68e51891440e4da0b65a70c&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="430" data-cart_item_key="f74909ace68e51891440e4da0b65a70c" data-product_sku="09"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/white-tea/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/white-tea/">White Tea</a> </h6>
<p class="qodef-e-quantity">Quantity: 3</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>31.05</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=cd89fef7ffdd490db800357f47722b20&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1062" data-cart_item_key="cd89fef7ffdd490db800357f47722b20" data-product_sku="019"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/cranberry/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/cranberry/">Cranberry</a> </h6>
<p class="qodef-e-quantity">Quantity: 2</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>39.09</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=a42a596fc71e17828440030074d15e74&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1194" data-cart_item_key="a42a596fc71e17828440030074d15e74" data-product_sku="025"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/jasmine/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/jasmine/">Jasmine</a> </h6>
<p class="qodef-e-quantity">Quantity: 1</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>25.00</bdi></span></p>
</div>
</li>
</ul>
<div class="qodef-m-order-details">
<h6 class="qodef-m-order-label">Total:</h6>
<div class="qodef-m-order-amount"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>1,747.85</bdi></span></div>
</div><div class="qodef-m-action">
<a itemprop="url" href="https://chaai.qodeinteractive.com/cart/" class="qodef-m-action-link">View Cart</a>
<a itemprop="url" href="https://chaai.qodeinteractive.com/checkout/" class="qodef-m-action-link">Checkout</a>
</div>
<div class="qodef-side-area-image">
<img src="https://chaai.qodeinteractive.com/wp-content/themes/chaai/assets/img/sidearea-image.png" />
</div><a class="qodef-m-close" href="#">
<span class="qodef-m-close-icon"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></span>
</a>
</div>
<div class="qodef-woo-side-area-cart-cover">
<svg class="qodef-svg--close-cart qodef-cart-close" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="51.19px" height="51.25px" viewBox="12.38 12.31 51.19 51.25" enable-background="new 12.38 12.31 51.19 51.25" xml:space="preserve" style="stroke-width: 1.2"><line fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" x1="63" y1="13" x2="13" y2="63" /><line fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" x1="13" y1="13" x2="63" y2="63" /></svg> </div>
</div>
</div><div id="chaai_core_button-2" class="widget widget_chaai_core_button qodef-header-widget-area-one" data-area="header-widget-one"><a class="qodef-shortcode qodef-m  qodef-button qodef-layout--textual  qodef-html--link" href="https://chaai.qodeinteractive.com/booking-page/" target="_self" style="font-size: 19px;margin: 0 23px 5px 40px"> <span class="qodef-m-text">Reservation</span></a></div> </div>
</div>
</div>
<div class="qodef-header-sticky">
<div class="qodef-header-sticky-inner">
<div class="qodef-divided-header-left-wrapper">
<nav class="qodef-header-navigation" role="navigation" aria-label="Divided Left Menu">
<ul id="menu-divided-left-1" class="menu"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1213 qodef-menu-item--narrow"><a href="#"><span class="qodef-menu-item-text">Home<svg class="qodef-svg--menu-arrow qodef-menu-item-arrow" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="12" height="8" viewBox="0 0 12.09 8.5" enable-background="new 0 0 12.09 8.5" xml:space="preserve"><g><path d="M11.98,4.02c0.06,0.06,0.09,0.14,0.09,0.23c0,0.09-0.03,0.17-0.09,0.23l-3.9,3.9C8.05,8.41,8.02,8.44,7.97,8.45
            C7.94,8.47,7.89,8.48,7.85,8.48S7.77,8.47,7.73,8.45C7.69,8.44,7.65,8.41,7.62,8.38c-0.06-0.06-0.1-0.14-0.1-0.23
            s0.03-0.17,0.1-0.23l3.35-3.35H0.38c-0.09,0-0.17-0.03-0.23-0.09s-0.1-0.14-0.1-0.23c0-0.09,0.03-0.17,0.1-0.24
            c0.06-0.06,0.14-0.09,0.23-0.09h10.59L7.62,0.58c-0.06-0.06-0.1-0.14-0.1-0.23s0.03-0.17,0.1-0.23c0.06-0.06,0.14-0.1,0.23-0.1
            c0.09,0,0.16,0.03,0.23,0.1L11.98,4.02z" /></g></svg></span></a>
<div class="qodef-drop-down-second"><div class="qodef-drop-down-second-inner"><ul class="sub-menu">
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-1214"><a href="https://chaai.qodeinteractive.com/"><span class="qodef-menu-item-text">Main Home</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1215"><a href="https://chaai.qodeinteractive.com/tea-shop/"><span class="qodef-menu-item-text">Tea Shop</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1216"><a href="https://chaai.qodeinteractive.com/tea-house/"><span class="qodef-menu-item-text">Tea House</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1502"><a href="https://chaai.qodeinteractive.com/landing/"><span class="qodef-menu-item-text">Landing</span></a></li>
</ul></div></div>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1217 qodef-menu-item--narrow"><a href="#"><span class="qodef-menu-item-text">Pages<svg class="qodef-svg--menu-arrow qodef-menu-item-arrow" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="12" height="8" viewBox="0 0 12.09 8.5" enable-background="new 0 0 12.09 8.5" xml:space="preserve"><g><path d="M11.98,4.02c0.06,0.06,0.09,0.14,0.09,0.23c0,0.09-0.03,0.17-0.09,0.23l-3.9,3.9C8.05,8.41,8.02,8.44,7.97,8.45
            C7.94,8.47,7.89,8.48,7.85,8.48S7.77,8.47,7.73,8.45C7.69,8.44,7.65,8.41,7.62,8.38c-0.06-0.06-0.1-0.14-0.1-0.23
            s0.03-0.17,0.1-0.23l3.35-3.35H0.38c-0.09,0-0.17-0.03-0.23-0.09s-0.1-0.14-0.1-0.23c0-0.09,0.03-0.17,0.1-0.24
            c0.06-0.06,0.14-0.09,0.23-0.09h10.59L7.62,0.58c-0.06-0.06-0.1-0.14-0.1-0.23s0.03-0.17,0.1-0.23c0.06-0.06,0.14-0.1,0.23-0.1
            c0.09,0,0.16,0.03,0.23,0.1L11.98,4.02z" /></g></svg></span></a>
<div class="qodef-drop-down-second"><div class="qodef-drop-down-second-inner"><ul class="sub-menu">
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1218"><a href="https://chaai.qodeinteractive.com/about-us/"><span class="qodef-menu-item-text">About Us</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1222"><a href="https://chaai.qodeinteractive.com/our-team/"><span class="qodef-menu-item-text">Our Team</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1221"><a href="https://chaai.qodeinteractive.com/our-menu/"><span class="qodef-menu-item-text">Our Menu</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1219"><a href="https://chaai.qodeinteractive.com/booking-page/"><span class="qodef-menu-item-text">Booking</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1220"><a href="https://chaai.qodeinteractive.com/our-location/"><span class="qodef-menu-item-text">Our Location</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1538"><a href="https://chaai.qodeinteractive.com/contact-us/"><span class="qodef-menu-item-text">Contact Us</span></a></li>
</ul></div></div>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1223 qodef-menu-item--narrow"><a href="#"><span class="qodef-menu-item-text">Shop<svg class="qodef-svg--menu-arrow qodef-menu-item-arrow" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="12" height="8" viewBox="0 0 12.09 8.5" enable-background="new 0 0 12.09 8.5" xml:space="preserve"><g><path d="M11.98,4.02c0.06,0.06,0.09,0.14,0.09,0.23c0,0.09-0.03,0.17-0.09,0.23l-3.9,3.9C8.05,8.41,8.02,8.44,7.97,8.45
            C7.94,8.47,7.89,8.48,7.85,8.48S7.77,8.47,7.73,8.45C7.69,8.44,7.65,8.41,7.62,8.38c-0.06-0.06-0.1-0.14-0.1-0.23
            s0.03-0.17,0.1-0.23l3.35-3.35H0.38c-0.09,0-0.17-0.03-0.23-0.09s-0.1-0.14-0.1-0.23c0-0.09,0.03-0.17,0.1-0.24
            c0.06-0.06,0.14-0.09,0.23-0.09h10.59L7.62,0.58c-0.06-0.06-0.1-0.14-0.1-0.23s0.03-0.17,0.1-0.23c0.06-0.06,0.14-0.1,0.23-0.1
            c0.09,0,0.16,0.03,0.23,0.1L11.98,4.02z" /></g></svg></span></a>
<div class="qodef-drop-down-second"><div class="qodef-drop-down-second-inner"><ul class="sub-menu">
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1225"><a href="https://chaai.qodeinteractive.com/shop/"><span class="qodef-menu-item-text">Shop List</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-product menu-item-1229"><a href="https://chaai.qodeinteractive.com/product/bouquet/"><span class="qodef-menu-item-text">Shop Single</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2827"><a href="https://chaai.qodeinteractive.com/shop/shop-slider/"><span class="qodef-menu-item-text">Shop Slider</span></a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1233"><a href="#"><span class="qodef-menu-item-text">Shop Layouts<svg class="qodef-svg--menu-arrow qodef-menu-item-arrow" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="12" height="8" viewBox="0 0 12.09 8.5" enable-background="new 0 0 12.09 8.5" xml:space="preserve"><g><path d="M11.98,4.02c0.06,0.06,0.09,0.14,0.09,0.23c0,0.09-0.03,0.17-0.09,0.23l-3.9,3.9C8.05,8.41,8.02,8.44,7.97,8.45
            C7.94,8.47,7.89,8.48,7.85,8.48S7.77,8.47,7.73,8.45C7.69,8.44,7.65,8.41,7.62,8.38c-0.06-0.06-0.1-0.14-0.1-0.23
            s0.03-0.17,0.1-0.23l3.35-3.35H0.38c-0.09,0-0.17-0.03-0.23-0.09s-0.1-0.14-0.1-0.23c0-0.09,0.03-0.17,0.1-0.24
            c0.06-0.06,0.14-0.09,0.23-0.09h10.59L7.62,0.58c-0.06-0.06-0.1-0.14-0.1-0.23s0.03-0.17,0.1-0.23c0.06-0.06,0.14-0.1,0.23-0.1
            c0.09,0,0.16,0.03,0.23,0.1L11.98,4.02z" /></g></svg></span></a>
<ul class="sub-menu">
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1234"><a href="https://chaai.qodeinteractive.com/shop/three-columns/"><span class="qodef-menu-item-text">Three Columns</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1235"><a href="https://chaai.qodeinteractive.com/shop/three-columns-wide/"><span class="qodef-menu-item-text">Three Columns Wide</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1236"><a href="https://chaai.qodeinteractive.com/shop/four-columns/"><span class="qodef-menu-item-text">Four Columns</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1237"><a href="https://chaai.qodeinteractive.com/shop/four-columns-wide/"><span class="qodef-menu-item-text">Four Columns Wide</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1238"><a href="https://chaai.qodeinteractive.com/shop/five-columns-wide/"><span class="qodef-menu-item-text">Five Columns Wide</span></a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1266 qodef--hide-link"><a href="#" onclick="JavaScript: return false;"><span class="qodef-menu-item-text">Shop Pages<svg class="qodef-svg--menu-arrow qodef-menu-item-arrow" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="12" height="8" viewBox="0 0 12.09 8.5" enable-background="new 0 0 12.09 8.5" xml:space="preserve"><g><path d="M11.98,4.02c0.06,0.06,0.09,0.14,0.09,0.23c0,0.09-0.03,0.17-0.09,0.23l-3.9,3.9C8.05,8.41,8.02,8.44,7.97,8.45
            C7.94,8.47,7.89,8.48,7.85,8.48S7.77,8.47,7.73,8.45C7.69,8.44,7.65,8.41,7.62,8.38c-0.06-0.06-0.1-0.14-0.1-0.23
            s0.03-0.17,0.1-0.23l3.35-3.35H0.38c-0.09,0-0.17-0.03-0.23-0.09s-0.1-0.14-0.1-0.23c0-0.09,0.03-0.17,0.1-0.24
            c0.06-0.06,0.14-0.09,0.23-0.09h10.59L7.62,0.58c-0.06-0.06-0.1-0.14-0.1-0.23s0.03-0.17,0.1-0.23c0.06-0.06,0.14-0.1,0.23-0.1
            c0.09,0,0.16,0.03,0.23,0.1L11.98,4.02z" /></g></svg></span></a>
<ul class="sub-menu">
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1265"><a href="https://chaai.qodeinteractive.com/my-account/"><span class="qodef-menu-item-text">My Account</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1263"><a href="https://chaai.qodeinteractive.com/cart/"><span class="qodef-menu-item-text">Cart</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1264"><a href="https://chaai.qodeinteractive.com/checkout/"><span class="qodef-menu-item-text">Checkout</span></a></li>
</ul>
</li>
</ul></div></div>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1240 qodef-menu-item--narrow"><a href="#"><span class="qodef-menu-item-text">Blog<svg class="qodef-svg--menu-arrow qodef-menu-item-arrow" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="12" height="8" viewBox="0 0 12.09 8.5" enable-background="new 0 0 12.09 8.5" xml:space="preserve"><g><path d="M11.98,4.02c0.06,0.06,0.09,0.14,0.09,0.23c0,0.09-0.03,0.17-0.09,0.23l-3.9,3.9C8.05,8.41,8.02,8.44,7.97,8.45
            C7.94,8.47,7.89,8.48,7.85,8.48S7.77,8.47,7.73,8.45C7.69,8.44,7.65,8.41,7.62,8.38c-0.06-0.06-0.1-0.14-0.1-0.23
            s0.03-0.17,0.1-0.23l3.35-3.35H0.38c-0.09,0-0.17-0.03-0.23-0.09s-0.1-0.14-0.1-0.23c0-0.09,0.03-0.17,0.1-0.24
            c0.06-0.06,0.14-0.09,0.23-0.09h10.59L7.62,0.58c-0.06-0.06-0.1-0.14-0.1-0.23s0.03-0.17,0.1-0.23c0.06-0.06,0.14-0.1,0.23-0.1
            c0.09,0,0.16,0.03,0.23,0.1L11.98,4.02z" /></g></svg></span></a>
<div class="qodef-drop-down-second"><div class="qodef-drop-down-second-inner"><ul class="sub-menu">
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1241"><a href="https://chaai.qodeinteractive.com/blog-standard/"><span class="qodef-menu-item-text">Blog Right Sidebar</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1242"><a href="https://chaai.qodeinteractive.com/blog-left-sidebar/"><span class="qodef-menu-item-text">Blog Left Sidebar</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1243"><a href="https://chaai.qodeinteractive.com/blog-no-sidebar/"><span class="qodef-menu-item-text">Blog No Sidebar</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3040"><a href="https://chaai.qodeinteractive.com/blog-slider/"><span class="qodef-menu-item-text">Blog Slider</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1244"><a href="https://chaai.qodeinteractive.com/pinterest-blog-list/"><span class="qodef-menu-item-text">Blog Pinterest</span></a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1245"><a href="#"><span class="qodef-menu-item-text">Post Types<svg class="qodef-svg--menu-arrow qodef-menu-item-arrow" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="12" height="8" viewBox="0 0 12.09 8.5" enable-background="new 0 0 12.09 8.5" xml:space="preserve"><g><path d="M11.98,4.02c0.06,0.06,0.09,0.14,0.09,0.23c0,0.09-0.03,0.17-0.09,0.23l-3.9,3.9C8.05,8.41,8.02,8.44,7.97,8.45
            C7.94,8.47,7.89,8.48,7.85,8.48S7.77,8.47,7.73,8.45C7.69,8.44,7.65,8.41,7.62,8.38c-0.06-0.06-0.1-0.14-0.1-0.23
            s0.03-0.17,0.1-0.23l3.35-3.35H0.38c-0.09,0-0.17-0.03-0.23-0.09s-0.1-0.14-0.1-0.23c0-0.09,0.03-0.17,0.1-0.24
            c0.06-0.06,0.14-0.09,0.23-0.09h10.59L7.62,0.58c-0.06-0.06-0.1-0.14-0.1-0.23s0.03-0.17,0.1-0.23c0.06-0.06,0.14-0.1,0.23-0.1
            c0.09,0,0.16,0.03,0.23,0.1L11.98,4.02z" /></g></svg></span></a>
<ul class="sub-menu">
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1246"><a href="https://chaai.qodeinteractive.com/popular-tea-shops-in-japan/"><span class="qodef-menu-item-text">Standard Post</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1247"><a href="https://chaai.qodeinteractive.com/everyday-tea/"><span class="qodef-menu-item-text">Link Post</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1248"><a href="https://chaai.qodeinteractive.com/tea-world/"><span class="qodef-menu-item-text">Quote Post</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1249"><a href="https://chaai.qodeinteractive.com/enjoy-every-moment/"><span class="qodef-menu-item-text">Audio Post</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1250"><a href="https://chaai.qodeinteractive.com/fantastic-taste-of-tea-flavor/"><span class="qodef-menu-item-text">Galery Post</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1251"><a href="https://chaai.qodeinteractive.com/learn-more-about-tea/"><span class="qodef-menu-item-text">Video Post</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-2828"><a href="https://chaai.qodeinteractive.com/inspiration-in-tea/"><span class="qodef-menu-item-text">No Sidebar Post</span></a></li>
</ul>
</li>
</ul></div></div>
</li>
</ul> </nav>
</div>
<a itemprop="url" class="qodef-header-logo-link qodef-height--not-set qodef-source--image" href="https://chaai.qodeinteractive.com/" rel="home">
<img width="260" height="56" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/10/chaai-home-2-logo1.png" class="qodef-header-logo-image qodef--main" alt="logo main" itemprop="image" /></a>
<div class="qodef-divided-header-right-wrapper">
<div class="qodef-widget-holder qodef--one">
<div id="chaai_core_woo_side_area_cart-3" class="widget widget_chaai_core_woo_side_area_cart qodef-sticky-right"> <div class="qodef-widget-side-area-cart-inner">
<a itemprop="url" class="qodef-m-opener" href="https://chaai.qodeinteractive.com/cart/">
<span class="qodef-m-opener-icon">
<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="16" height="21" viewBox="0 0 16.92 21.42" enable-background="new 0 0 16.92 21.42" xml:space="preserve">
<g>
<path fill="none" stroke-width="1.15" stroke-linecap="round" stroke-miterlimit="10" d="M5,4.98l0.02-0.76
                    c0-1.92,1.56-3.48,3.48-3.48l0,0c1.92,0,3.48,1.56,3.48,3.48l-0.02,0.76" />
<path fill="none" stroke-width="1.15" stroke-linejoin="round" stroke-miterlimit="10" d="M15.5,5.92l0.77,13.91
                    c0.03,0.5-0.37,0.92-0.87,0.92H1.59c-0.5,0-0.9-0.42-0.87-0.92L1.5,5.92C1.52,5.46,1.9,5.1,2.37,5.1h12.27
                    C15.1,5.1,15.48,5.46,15.5,5.92z" />
</g>
</svg>
</span>
<span class="qodef-m-opener-count">(50)</span>
</a>
<div class="qodef-widget-side-area-cart-content">
<ul class="qodef-woo-side-area-cart">
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=13f3cf8c531952d72e5847c4183e6910&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="443" data-cart_item_key="13f3cf8c531952d72e5847c4183e6910" data-product_sku="010"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/fruit-tea/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/fruit-tea/">Fruit Tea</a> </h6>
<p class="qodef-e-quantity">Quantity: 1</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>39.09</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=ab817c9349cf9c4f6877e1894a1faa00&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="467" data-cart_item_key="ab817c9349cf9c4f6877e1894a1faa00" data-product_sku="012"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/exotic-tea/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/exotic-tea/">Exotic Tea</a> </h6>
<p class="qodef-e-quantity">Quantity: 2</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>26.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=dc6a6489640ca02b0d42dabeb8e46bb7&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="469" data-cart_item_key="dc6a6489640ca02b0d42dabeb8e46bb7" data-product_sku="013"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/white-peony/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/white-peony/">White Peony</a> </h6>
<p class="qodef-e-quantity">Quantity: 2</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>37.05</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=43dd49b4fdb9bede653e94468ff8df1e&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1066" data-cart_item_key="43dd49b4fdb9bede653e94468ff8df1e" data-product_sku="020"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/liberty-tea/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/liberty-tea/">Liberty Tea</a> </h6>
<p class="qodef-e-quantity">Quantity: 1</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>37.05</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=53adaf494dc89ef7196d73636eb2451b&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1068" data-cart_item_key="53adaf494dc89ef7196d73636eb2451b" data-product_sku="021"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/golden-elixir/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/golden-elixir/">Golden Elixir</a> </h6>
<p class="qodef-e-quantity">Quantity: 2</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>20.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=1b0114c51cc532ed34e1954b5b9e4b58&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1071" data-cart_item_key="1b0114c51cc532ed34e1954b5b9e4b58" data-product_sku="022"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/hibiscus/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/hibiscus/">Hibiscus</a> </h6>
<p class="qodef-e-quantity">Quantity: 2</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>29.05</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=390e982518a50e280d8e2b535462ec1f&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1073" data-cart_item_key="390e982518a50e280d8e2b535462ec1f" data-product_sku="023"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/china-chai/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/china-chai/">China Chai</a> </h6>
<p class="qodef-e-quantity">Quantity: 1</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>27.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=4a08142c38dbe374195d41c04562d9f8&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1059" data-cart_item_key="4a08142c38dbe374195d41c04562d9f8" data-product_sku="018"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/rooibos/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/rooibos/">Rooibos</a> </h6>
<p class="qodef-e-quantity">Quantity: 3</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>37.05</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=27ed0fb950b856b06e1273989422e7d3&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1039" data-cart_item_key="27ed0fb950b856b06e1273989422e7d3" data-product_sku="014"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/bouquet/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/bouquet/">Bouquet</a> </h6>
<p class="qodef-e-quantity">Quantity: 1</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>25.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=7cce53cf90577442771720a370c3c723&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1048" data-cart_item_key="7cce53cf90577442771720a370c3c723" data-product_sku="016"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/rou-gui/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/rou-gui/">Rou Gui</a> </h6>
<p class="qodef-e-quantity">Quantity: 3</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>39.09</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=5055cbf43fac3f7e2336b27310f0b9ef&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1050" data-cart_item_key="5055cbf43fac3f7e2336b27310f0b9ef" data-product_sku="017"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/masala-chai/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img5-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img5-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img5-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img5-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img5-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img5.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/masala-chai/">Masala Chai</a> </h6>
<p class="qodef-e-quantity">Quantity: 1</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>330.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=a0e2a2c563d57df27213ede1ac4ac780&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1045" data-cart_item_key="a0e2a2c563d57df27213ede1ac4ac780" data-product_sku="015"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/yellow-bud/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/yellow-bud/">Yellow Bud</a> </h6>
<p class="qodef-e-quantity">Quantity: 2</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>20.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=6faa8040da20ef399b63a72d0e4ab575&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="329" data-cart_item_key="6faa8040da20ef399b63a72d0e4ab575" data-product_sku="01"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/sage/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/sage/">Sage</a> </h6>
<p class="qodef-e-quantity">Quantity: 2</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>25.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=bbcbff5c1f1ded46c25d28119a85c6c2&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="405" data-cart_item_key="bbcbff5c1f1ded46c25d28119a85c6c2" data-product_sku="02"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/chamomile/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/chamomile/">Chamomile</a> </h6>
<p class="qodef-e-quantity">Quantity: 3</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>20.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=f4f6dce2f3a0f9dada0c2b5b66452017&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="407" data-cart_item_key="f4f6dce2f3a0f9dada0c2b5b66452017" data-product_sku="03"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/motherwort/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/motherwort/">Motherwort</a> </h6>
<p class="qodef-e-quantity">Quantity: 2</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>27.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=a96b65a721e561e1e3de768ac819ffbb&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="409" data-cart_item_key="a96b65a721e561e1e3de768ac819ffbb" data-product_sku="04"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/oriental-mix/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/oriental-mix/">Oriental Mix</a> </h6>
<p class="qodef-e-quantity">Quantity: 4</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>30.09</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=faa9afea49ef2ff029a833cccc778fd0&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="423" data-cart_item_key="faa9afea49ef2ff029a833cccc778fd0" data-product_sku="06"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/yunnan-tea/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img9-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img9-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img9-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img9-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img9-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img9.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/yunnan-tea/">Yunnan Tea</a> </h6>
<p class="qodef-e-quantity">Quantity: 4</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>23.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=25b2822c2f5a3230abfadd476e8b04c9&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="425" data-cart_item_key="25b2822c2f5a3230abfadd476e8b04c9" data-product_sku="07"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/sunset-ice/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/sunset-ice/">Sunset Ice</a> </h6>
<p class="qodef-e-quantity">Quantity: 4</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>27.05</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=18997733ec258a9fcaf239cc55d53363&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="427" data-cart_item_key="18997733ec258a9fcaf239cc55d53363" data-product_sku="08"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/phoenix-eyes/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/phoenix-eyes/">Phoenix Eyes</a> </h6>
<p class="qodef-e-quantity">Quantity: 4</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>29.05</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=f74909ace68e51891440e4da0b65a70c&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="430" data-cart_item_key="f74909ace68e51891440e4da0b65a70c" data-product_sku="09"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/white-tea/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/white-tea/">White Tea</a> </h6>
<p class="qodef-e-quantity">Quantity: 3</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>31.05</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=cd89fef7ffdd490db800357f47722b20&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1062" data-cart_item_key="cd89fef7ffdd490db800357f47722b20" data-product_sku="019"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/cranberry/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/cranberry/">Cranberry</a> </h6>
<p class="qodef-e-quantity">Quantity: 2</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>39.09</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=a42a596fc71e17828440030074d15e74&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1194" data-cart_item_key="a42a596fc71e17828440030074d15e74" data-product_sku="025"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/jasmine/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/jasmine/">Jasmine</a> </h6>
<p class="qodef-e-quantity">Quantity: 1</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>25.00</bdi></span></p>
</div>
</li>
</ul>
<div class="qodef-m-order-details">
<h6 class="qodef-m-order-label">Total:</h6>
<div class="qodef-m-order-amount"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>1,747.85</bdi></span></div>
</div><div class="qodef-m-action">
<a itemprop="url" href="https://chaai.qodeinteractive.com/cart/" class="qodef-m-action-link">View Cart</a>
<a itemprop="url" href="https://chaai.qodeinteractive.com/checkout/" class="qodef-m-action-link">Checkout</a>
</div>
<div class="qodef-side-area-image">
<img src="https://chaai.qodeinteractive.com/wp-content/themes/chaai/assets/img/sidearea-image.png" />
</div><a class="qodef-m-close" href="#">
<span class="qodef-m-close-icon"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></span>
</a>
</div>
<div class="qodef-woo-side-area-cart-cover">
<svg class="qodef-svg--close-cart qodef-cart-close" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="51.19px" height="51.25px" viewBox="12.38 12.31 51.19 51.25" enable-background="new 12.38 12.31 51.19 51.25" xml:space="preserve" style="stroke-width: 1.2"><line fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" x1="63" y1="13" x2="13" y2="63" /><line fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" x1="13" y1="13" x2="63" y2="63" /></svg> </div>
</div>
</div><div id="chaai_core_button-4" class="widget widget_chaai_core_button qodef-sticky-right"><a class="qodef-shortcode qodef-m  qodef-button qodef-layout--textual  qodef-html--link" href="https://chaai.qodeinteractive.com/booking-page/" target="_self" style="font-size: 19px;margin: 0 23px 5px 40px"> <span class="qodef-m-text">Reservation</span></a></div> </div>
</div>
</div>
</div>
</header>
<header id="qodef-page-mobile-header" role="banner">
<div id="qodef-page-mobile-header-inner" class>
<a itemprop="url" class="qodef-mobile-header-logo-link qodef-height--set qodef-source--image" href="https://chaai.qodeinteractive.com/" rel="home">
<img width="260" height="56" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/10/chaai-home-2-logo1.png" class="qodef-header-logo-image qodef--main" alt="logo main" itemprop="image" /></a>
<div class="qodef-widget-holder qodef--one">
<div id="chaai_core_woo_side_area_cart-4" class="widget widget_chaai_core_woo_side_area_cart qodef-mobile-header-widget-area-one" data-area="mobile-header"> <div class="qodef-widget-side-area-cart-inner">
<a itemprop="url" class="qodef-m-opener" href="https://chaai.qodeinteractive.com/cart/">
<span class="qodef-m-opener-icon">
<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="16" height="21" viewBox="0 0 16.92 21.42" enable-background="new 0 0 16.92 21.42" xml:space="preserve">
<g>
<path fill="none" stroke-width="1.15" stroke-linecap="round" stroke-miterlimit="10" d="M5,4.98l0.02-0.76
                    c0-1.92,1.56-3.48,3.48-3.48l0,0c1.92,0,3.48,1.56,3.48,3.48l-0.02,0.76" />
<path fill="none" stroke-width="1.15" stroke-linejoin="round" stroke-miterlimit="10" d="M15.5,5.92l0.77,13.91
                    c0.03,0.5-0.37,0.92-0.87,0.92H1.59c-0.5,0-0.9-0.42-0.87-0.92L1.5,5.92C1.52,5.46,1.9,5.1,2.37,5.1h12.27
                    C15.1,5.1,15.48,5.46,15.5,5.92z" />
</g>
</svg>
</span>
<span class="qodef-m-opener-count">(50)</span>
</a>
<div class="qodef-widget-side-area-cart-content">
<ul class="qodef-woo-side-area-cart">
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=13f3cf8c531952d72e5847c4183e6910&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="443" data-cart_item_key="13f3cf8c531952d72e5847c4183e6910" data-product_sku="010"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/fruit-tea/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/fruit-tea/">Fruit Tea</a> </h6>
<p class="qodef-e-quantity">Quantity: 1</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>39.09</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=ab817c9349cf9c4f6877e1894a1faa00&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="467" data-cart_item_key="ab817c9349cf9c4f6877e1894a1faa00" data-product_sku="012"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/exotic-tea/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/exotic-tea/">Exotic Tea</a> </h6>
<p class="qodef-e-quantity">Quantity: 2</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>26.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=dc6a6489640ca02b0d42dabeb8e46bb7&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="469" data-cart_item_key="dc6a6489640ca02b0d42dabeb8e46bb7" data-product_sku="013"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/white-peony/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/white-peony/">White Peony</a> </h6>
<p class="qodef-e-quantity">Quantity: 2</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>37.05</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=43dd49b4fdb9bede653e94468ff8df1e&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1066" data-cart_item_key="43dd49b4fdb9bede653e94468ff8df1e" data-product_sku="020"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/liberty-tea/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/liberty-tea/">Liberty Tea</a> </h6>
<p class="qodef-e-quantity">Quantity: 1</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>37.05</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=53adaf494dc89ef7196d73636eb2451b&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1068" data-cart_item_key="53adaf494dc89ef7196d73636eb2451b" data-product_sku="021"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/golden-elixir/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/golden-elixir/">Golden Elixir</a> </h6>
<p class="qodef-e-quantity">Quantity: 2</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>20.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=1b0114c51cc532ed34e1954b5b9e4b58&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1071" data-cart_item_key="1b0114c51cc532ed34e1954b5b9e4b58" data-product_sku="022"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/hibiscus/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/hibiscus/">Hibiscus</a> </h6>
<p class="qodef-e-quantity">Quantity: 2</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>29.05</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=390e982518a50e280d8e2b535462ec1f&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1073" data-cart_item_key="390e982518a50e280d8e2b535462ec1f" data-product_sku="023"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/china-chai/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/china-chai/">China Chai</a> </h6>
<p class="qodef-e-quantity">Quantity: 1</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>27.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=4a08142c38dbe374195d41c04562d9f8&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1059" data-cart_item_key="4a08142c38dbe374195d41c04562d9f8" data-product_sku="018"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/rooibos/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/rooibos/">Rooibos</a> </h6>
<p class="qodef-e-quantity">Quantity: 3</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>37.05</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=27ed0fb950b856b06e1273989422e7d3&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1039" data-cart_item_key="27ed0fb950b856b06e1273989422e7d3" data-product_sku="014"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/bouquet/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/bouquet/">Bouquet</a> </h6>
<p class="qodef-e-quantity">Quantity: 1</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>25.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=7cce53cf90577442771720a370c3c723&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1048" data-cart_item_key="7cce53cf90577442771720a370c3c723" data-product_sku="016"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/rou-gui/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/rou-gui/">Rou Gui</a> </h6>
<p class="qodef-e-quantity">Quantity: 3</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>39.09</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=5055cbf43fac3f7e2336b27310f0b9ef&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1050" data-cart_item_key="5055cbf43fac3f7e2336b27310f0b9ef" data-product_sku="017"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/masala-chai/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img5-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img5-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img5-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img5-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img5-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img5.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/masala-chai/">Masala Chai</a> </h6>
<p class="qodef-e-quantity">Quantity: 1</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>330.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=a0e2a2c563d57df27213ede1ac4ac780&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1045" data-cart_item_key="a0e2a2c563d57df27213ede1ac4ac780" data-product_sku="015"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/yellow-bud/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/yellow-bud/">Yellow Bud</a> </h6>
<p class="qodef-e-quantity">Quantity: 2</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>20.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=6faa8040da20ef399b63a72d0e4ab575&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="329" data-cart_item_key="6faa8040da20ef399b63a72d0e4ab575" data-product_sku="01"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/sage/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img1.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/sage/">Sage</a> </h6>
<p class="qodef-e-quantity">Quantity: 2</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>25.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=bbcbff5c1f1ded46c25d28119a85c6c2&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="405" data-cart_item_key="bbcbff5c1f1ded46c25d28119a85c6c2" data-product_sku="02"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/chamomile/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img2.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/chamomile/">Chamomile</a> </h6>
<p class="qodef-e-quantity">Quantity: 3</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>20.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=f4f6dce2f3a0f9dada0c2b5b66452017&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="407" data-cart_item_key="f4f6dce2f3a0f9dada0c2b5b66452017" data-product_sku="03"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/motherwort/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img3.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/motherwort/">Motherwort</a> </h6>
<p class="qodef-e-quantity">Quantity: 2</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>27.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=a96b65a721e561e1e3de768ac819ffbb&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="409" data-cart_item_key="a96b65a721e561e1e3de768ac819ffbb" data-product_sku="04"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/oriental-mix/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/oriental-mix/">Oriental Mix</a> </h6>
<p class="qodef-e-quantity">Quantity: 4</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>30.09</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=faa9afea49ef2ff029a833cccc778fd0&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="423" data-cart_item_key="faa9afea49ef2ff029a833cccc778fd0" data-product_sku="06"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/yunnan-tea/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img9-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img9-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img9-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img9-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img9-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img9.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/yunnan-tea/">Yunnan Tea</a> </h6>
<p class="qodef-e-quantity">Quantity: 4</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>23.00</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=25b2822c2f5a3230abfadd476e8b04c9&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="425" data-cart_item_key="25b2822c2f5a3230abfadd476e8b04c9" data-product_sku="07"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/sunset-ice/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/sunset-ice/">Sunset Ice</a> </h6>
<p class="qodef-e-quantity">Quantity: 4</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>27.05</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=18997733ec258a9fcaf239cc55d53363&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="427" data-cart_item_key="18997733ec258a9fcaf239cc55d53363" data-product_sku="08"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/phoenix-eyes/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img7.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/phoenix-eyes/">Phoenix Eyes</a> </h6>
<p class="qodef-e-quantity">Quantity: 4</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>29.05</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=f74909ace68e51891440e4da0b65a70c&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="430" data-cart_item_key="f74909ace68e51891440e4da0b65a70c" data-product_sku="09"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/white-tea/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img8.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/white-tea/">White Tea</a> </h6>
<p class="qodef-e-quantity">Quantity: 3</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>31.05</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=cd89fef7ffdd490db800357f47722b20&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1062" data-cart_item_key="cd89fef7ffdd490db800357f47722b20" data-product_sku="019"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/cranberry/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img4.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/cranberry/">Cranberry</a> </h6>
<p class="qodef-e-quantity">Quantity: 2</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>39.09</bdi></span></p>
</div>
</li>
<li class="qodef-woo-side-area-cart-item qodef-e">
<a href="https://chaai.qodeinteractive.com/cart/?remove_item=a42a596fc71e17828440030074d15e74&#038;_wpnonce=a96db29037" class="qodef-e-remove remove remove_from_cart_button" aria-label="Remove this item" data-product_id="1194" data-cart_item_key="a42a596fc71e17828440030074d15e74" data-product_sku="025"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></a> <div class="qodef-e-image">
<a href="https://chaai.qodeinteractive.com/product/jasmine/"><img width="600" height="818" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-600x818.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="j" srcset="https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-600x818.jpg 600w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-220x300.jpg 220w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-751x1024.jpg 751w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6-768x1047.jpg 768w, https://chaai.qodeinteractive.com/wp-content/uploads/2021/08/shop-list-img6.jpg 800w" sizes="(max-width: 600px) 100vw, 600px" /></a> </div>
<div class="qodef-e-content">
<h6 itemprop="name" class="qodef-e-title entry-title">
<a href="https://chaai.qodeinteractive.com/product/jasmine/">Jasmine</a> </h6>
<p class="qodef-e-quantity">Quantity: 1</p>
<p class="qodef-e-price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>25.00</bdi></span></p>
</div>
</li>
</ul>
<div class="qodef-m-order-details">
<h6 class="qodef-m-order-label">Total:</h6>
<div class="qodef-m-order-amount"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#36;</span>1,747.85</bdi></span></div>
</div><div class="qodef-m-action">
<a itemprop="url" href="https://chaai.qodeinteractive.com/cart/" class="qodef-m-action-link">View Cart</a>
<a itemprop="url" href="https://chaai.qodeinteractive.com/checkout/" class="qodef-m-action-link">Checkout</a>
</div>
<div class="qodef-side-area-image">
<img src="https://chaai.qodeinteractive.com/wp-content/themes/chaai/assets/img/sidearea-image.png" />
</div><a class="qodef-m-close" href="#">
<span class="qodef-m-close-icon"><span class="qodef-icon-linear-icons lnr lnr-cross"></span></span>
</a>
</div>
<div class="qodef-woo-side-area-cart-cover">
<svg class="qodef-svg--close-cart qodef-cart-close" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="51.19px" height="51.25px" viewBox="12.38 12.31 51.19 51.25" enable-background="new 12.38 12.31 51.19 51.25" xml:space="preserve" style="stroke-width: 1.2"><line fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" x1="63" y1="13" x2="13" y2="63" /><line fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" x1="13" y1="13" x2="63" y2="63" /></svg> </div>
</div>
</div> </div>
<a href="javascript:void(0)" class="qodef-opener-icon qodef-m qodef-source--predefined qodef-mobile-header-opener">
<span class="qodef-m-icon qodef--open">
<span class="qodef-m-lines"><span class="qodef-m-line qodef--1"></span><span class="qodef-m-line qodef--2"></span><span class="qodef-m-line qodef--3"></span></span> </span>
<span class="qodef-m-icon qodef--close">
<span class="qodef-m-lines"><span class="qodef-m-line qodef--1"></span><span class="qodef-m-line qodef--2"></span><span class="qodef-m-line qodef--3"></span></span> </span>
</a>
</div>
<nav class="qodef-mobile-header-navigation" role="navigation" aria-label="Mobile Menu">
<ul id="menu-standard-menu-2" class><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-42 qodef--hide-link qodef-menu-item--narrow"><a href="#" onclick="JavaScript: return false;"><span class="qodef-menu-item-text">Home</span></a><svg class="qodef-svg--menu-arrow qodef-menu-item-arrow" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="12" height="8" viewBox="0 0 12.09 8.5" enable-background="new 0 0 12.09 8.5" xml:space="preserve"><g><path d="M11.98,4.02c0.06,0.06,0.09,0.14,0.09,0.23c0,0.09-0.03,0.17-0.09,0.23l-3.9,3.9C8.05,8.41,8.02,8.44,7.97,8.45
            C7.94,8.47,7.89,8.48,7.85,8.48S7.77,8.47,7.73,8.45C7.69,8.44,7.65,8.41,7.62,8.38c-0.06-0.06-0.1-0.14-0.1-0.23
            s0.03-0.17,0.1-0.23l3.35-3.35H0.38c-0.09,0-0.17-0.03-0.23-0.09s-0.1-0.14-0.1-0.23c0-0.09,0.03-0.17,0.1-0.24
            c0.06-0.06,0.14-0.09,0.23-0.09h10.59L7.62,0.58c-0.06-0.06-0.1-0.14-0.1-0.23s0.03-0.17,0.1-0.23c0.06-0.06,0.14-0.1,0.23-0.1
            c0.09,0,0.16,0.03,0.23,0.1L11.98,4.02z" /></g></svg>
<div class="qodef-drop-down-second"><div class="qodef-drop-down-second-inner"><ul class="sub-menu">
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-47"><a href="https://chaai.qodeinteractive.com/"><span class="qodef-menu-item-text">Main Home</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-158"><a href="https://chaai.qodeinteractive.com/tea-shop/"><span class="qodef-menu-item-text">Tea Shop</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1035"><a href="https://chaai.qodeinteractive.com/tea-house/"><span class="qodef-menu-item-text">Tea House</span></a></li>
</ul></div></div>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-43 qodef--hide-link qodef-menu-item--narrow"><a href="#" onclick="JavaScript: return false;"><span class="qodef-menu-item-text">Pages</span></a><svg class="qodef-svg--menu-arrow qodef-menu-item-arrow" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="12" height="8" viewBox="0 0 12.09 8.5" enable-background="new 0 0 12.09 8.5" xml:space="preserve"><g><path d="M11.98,4.02c0.06,0.06,0.09,0.14,0.09,0.23c0,0.09-0.03,0.17-0.09,0.23l-3.9,3.9C8.05,8.41,8.02,8.44,7.97,8.45
            C7.94,8.47,7.89,8.48,7.85,8.48S7.77,8.47,7.73,8.45C7.69,8.44,7.65,8.41,7.62,8.38c-0.06-0.06-0.1-0.14-0.1-0.23
            s0.03-0.17,0.1-0.23l3.35-3.35H0.38c-0.09,0-0.17-0.03-0.23-0.09s-0.1-0.14-0.1-0.23c0-0.09,0.03-0.17,0.1-0.24
            c0.06-0.06,0.14-0.09,0.23-0.09h10.59L7.62,0.58c-0.06-0.06-0.1-0.14-0.1-0.23s0.03-0.17,0.1-0.23c0.06-0.06,0.14-0.1,0.23-0.1
            c0.09,0,0.16,0.03,0.23,0.1L11.98,4.02z" /></g></svg>
<div class="qodef-drop-down-second"><div class="qodef-drop-down-second-inner"><ul class="sub-menu">
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-592"><a href="https://chaai.qodeinteractive.com/about-us/"><span class="qodef-menu-item-text">About Us</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-865"><a href="https://chaai.qodeinteractive.com/our-team/"><span class="qodef-menu-item-text">Our Team</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-866"><a href="https://chaai.qodeinteractive.com/our-menu/"><span class="qodef-menu-item-text">Our Menu</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-868"><a href="https://chaai.qodeinteractive.com/booking-page/"><span class="qodef-menu-item-text">Booking</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-867"><a href="https://chaai.qodeinteractive.com/our-location/"><span class="qodef-menu-item-text">Our Location</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1543"><a href="https://chaai.qodeinteractive.com/contact-us/"><span class="qodef-menu-item-text">Contact Us</span></a></li>
</ul></div></div>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-44 qodef--hide-link qodef-menu-item--narrow"><a href="#" onclick="JavaScript: return false;"><span class="qodef-menu-item-text">Shop</span></a><svg class="qodef-svg--menu-arrow qodef-menu-item-arrow" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="12" height="8" viewBox="0 0 12.09 8.5" enable-background="new 0 0 12.09 8.5" xml:space="preserve"><g><path d="M11.98,4.02c0.06,0.06,0.09,0.14,0.09,0.23c0,0.09-0.03,0.17-0.09,0.23l-3.9,3.9C8.05,8.41,8.02,8.44,7.97,8.45
            C7.94,8.47,7.89,8.48,7.85,8.48S7.77,8.47,7.73,8.45C7.69,8.44,7.65,8.41,7.62,8.38c-0.06-0.06-0.1-0.14-0.1-0.23
            s0.03-0.17,0.1-0.23l3.35-3.35H0.38c-0.09,0-0.17-0.03-0.23-0.09s-0.1-0.14-0.1-0.23c0-0.09,0.03-0.17,0.1-0.24
            c0.06-0.06,0.14-0.09,0.23-0.09h10.59L7.62,0.58c-0.06-0.06-0.1-0.14-0.1-0.23s0.03-0.17,0.1-0.23c0.06-0.06,0.14-0.1,0.23-0.1
            c0.09,0,0.16,0.03,0.23,0.1L11.98,4.02z" /></g></svg>
<div class="qodef-drop-down-second"><div class="qodef-drop-down-second-inner"><ul class="sub-menu">
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1185"><a href="https://chaai.qodeinteractive.com/shop/"><span class="qodef-menu-item-text">Shop List</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-product menu-item-1211"><a href="https://chaai.qodeinteractive.com/product/bouquet/"><span class="qodef-menu-item-text">Shop Single</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2822"><a href="https://chaai.qodeinteractive.com/shop/shop-slider/"><span class="qodef-menu-item-text">Shop Slider</span></a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1184 qodef--hide-link"><a href="#" onclick="JavaScript: return false;"><span class="qodef-menu-item-text">Shop Layouts</span></a><svg class="qodef-svg--menu-arrow qodef-menu-item-arrow" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="12" height="8" viewBox="0 0 12.09 8.5" enable-background="new 0 0 12.09 8.5" xml:space="preserve"><g><path d="M11.98,4.02c0.06,0.06,0.09,0.14,0.09,0.23c0,0.09-0.03,0.17-0.09,0.23l-3.9,3.9C8.05,8.41,8.02,8.44,7.97,8.45
            C7.94,8.47,7.89,8.48,7.85,8.48S7.77,8.47,7.73,8.45C7.69,8.44,7.65,8.41,7.62,8.38c-0.06-0.06-0.1-0.14-0.1-0.23
            s0.03-0.17,0.1-0.23l3.35-3.35H0.38c-0.09,0-0.17-0.03-0.23-0.09s-0.1-0.14-0.1-0.23c0-0.09,0.03-0.17,0.1-0.24
            c0.06-0.06,0.14-0.09,0.23-0.09h10.59L7.62,0.58c-0.06-0.06-0.1-0.14-0.1-0.23s0.03-0.17,0.1-0.23c0.06-0.06,0.14-0.1,0.23-0.1
            c0.09,0,0.16,0.03,0.23,0.1L11.98,4.02z" /></g></svg>
<ul class="sub-menu">
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1190"><a href="https://chaai.qodeinteractive.com/shop/three-columns/"><span class="qodef-menu-item-text">Three Columns</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1191"><a href="https://chaai.qodeinteractive.com/shop/three-columns-wide/"><span class="qodef-menu-item-text">Three Columns Wide</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1187"><a href="https://chaai.qodeinteractive.com/shop/four-columns/"><span class="qodef-menu-item-text">Four Columns</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1188"><a href="https://chaai.qodeinteractive.com/shop/four-columns-wide/"><span class="qodef-menu-item-text">Four Columns Wide</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1186"><a href="https://chaai.qodeinteractive.com/shop/five-columns-wide/"><span class="qodef-menu-item-text">Five Columns Wide</span></a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1270 qodef--hide-link"><a href="#" onclick="JavaScript: return false;"><span class="qodef-menu-item-text">Shop Pages</span></a><svg class="qodef-svg--menu-arrow qodef-menu-item-arrow" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="12" height="8" viewBox="0 0 12.09 8.5" enable-background="new 0 0 12.09 8.5" xml:space="preserve"><g><path d="M11.98,4.02c0.06,0.06,0.09,0.14,0.09,0.23c0,0.09-0.03,0.17-0.09,0.23l-3.9,3.9C8.05,8.41,8.02,8.44,7.97,8.45
            C7.94,8.47,7.89,8.48,7.85,8.48S7.77,8.47,7.73,8.45C7.69,8.44,7.65,8.41,7.62,8.38c-0.06-0.06-0.1-0.14-0.1-0.23
            s0.03-0.17,0.1-0.23l3.35-3.35H0.38c-0.09,0-0.17-0.03-0.23-0.09s-0.1-0.14-0.1-0.23c0-0.09,0.03-0.17,0.1-0.24
            c0.06-0.06,0.14-0.09,0.23-0.09h10.59L7.62,0.58c-0.06-0.06-0.1-0.14-0.1-0.23s0.03-0.17,0.1-0.23c0.06-0.06,0.14-0.1,0.23-0.1
            c0.09,0,0.16,0.03,0.23,0.1L11.98,4.02z" /></g></svg>
<ul class="sub-menu">
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1269"><a href="https://chaai.qodeinteractive.com/my-account/"><span class="qodef-menu-item-text">My Account</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1267"><a href="https://chaai.qodeinteractive.com/cart/"><span class="qodef-menu-item-text">Cart</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1268"><a href="https://chaai.qodeinteractive.com/checkout/"><span class="qodef-menu-item-text">Checkout</span></a></li>
</ul>
</li>
</ul></div></div>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-45 qodef--hide-link qodef-menu-item--narrow"><a href="#" onclick="JavaScript: return false;"><span class="qodef-menu-item-text">Blog</span></a><svg class="qodef-svg--menu-arrow qodef-menu-item-arrow" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="12" height="8" viewBox="0 0 12.09 8.5" enable-background="new 0 0 12.09 8.5" xml:space="preserve"><g><path d="M11.98,4.02c0.06,0.06,0.09,0.14,0.09,0.23c0,0.09-0.03,0.17-0.09,0.23l-3.9,3.9C8.05,8.41,8.02,8.44,7.97,8.45
            C7.94,8.47,7.89,8.48,7.85,8.48S7.77,8.47,7.73,8.45C7.69,8.44,7.65,8.41,7.62,8.38c-0.06-0.06-0.1-0.14-0.1-0.23
            s0.03-0.17,0.1-0.23l3.35-3.35H0.38c-0.09,0-0.17-0.03-0.23-0.09s-0.1-0.14-0.1-0.23c0-0.09,0.03-0.17,0.1-0.24
            c0.06-0.06,0.14-0.09,0.23-0.09h10.59L7.62,0.58c-0.06-0.06-0.1-0.14-0.1-0.23s0.03-0.17,0.1-0.23c0.06-0.06,0.14-0.1,0.23-0.1
            c0.09,0,0.16,0.03,0.23,0.1L11.98,4.02z" /></g></svg>
<div class="qodef-drop-down-second"><div class="qodef-drop-down-second-inner"><ul class="sub-menu">
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-581"><a href="https://chaai.qodeinteractive.com/blog-standard/"><span class="qodef-menu-item-text">Blog Right Sidebar</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1172"><a href="https://chaai.qodeinteractive.com/blog-left-sidebar/"><span class="qodef-menu-item-text">Blog Left Sidebar</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1171"><a href="https://chaai.qodeinteractive.com/blog-no-sidebar/"><span class="qodef-menu-item-text">Blog No Sidebar</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3041"><a href="https://chaai.qodeinteractive.com/blog-slider/"><span class="qodef-menu-item-text">Blog Slider</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-912"><a href="https://chaai.qodeinteractive.com/pinterest-blog-list/"><span class="qodef-menu-item-text">Blog Pinterest</span></a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-582"><a href="#"><span class="qodef-menu-item-text">Post Types</span></a><svg class="qodef-svg--menu-arrow qodef-menu-item-arrow" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="12" height="8" viewBox="0 0 12.09 8.5" enable-background="new 0 0 12.09 8.5" xml:space="preserve"><g><path d="M11.98,4.02c0.06,0.06,0.09,0.14,0.09,0.23c0,0.09-0.03,0.17-0.09,0.23l-3.9,3.9C8.05,8.41,8.02,8.44,7.97,8.45
            C7.94,8.47,7.89,8.48,7.85,8.48S7.77,8.47,7.73,8.45C7.69,8.44,7.65,8.41,7.62,8.38c-0.06-0.06-0.1-0.14-0.1-0.23
            s0.03-0.17,0.1-0.23l3.35-3.35H0.38c-0.09,0-0.17-0.03-0.23-0.09s-0.1-0.14-0.1-0.23c0-0.09,0.03-0.17,0.1-0.24
            c0.06-0.06,0.14-0.09,0.23-0.09h10.59L7.62,0.58c-0.06-0.06-0.1-0.14-0.1-0.23s0.03-0.17,0.1-0.23c0.06-0.06,0.14-0.1,0.23-0.1
            c0.09,0,0.16,0.03,0.23,0.1L11.98,4.02z" /></g></svg>
<ul class="sub-menu">
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1036"><a href="https://chaai.qodeinteractive.com/popular-tea-shops-in-japan/"><span class="qodef-menu-item-text">Standard Post</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1037"><a href="https://chaai.qodeinteractive.com/everyday-tea/"><span class="qodef-menu-item-text">Link Post</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1038"><a href="https://chaai.qodeinteractive.com/tea-world/"><span class="qodef-menu-item-text">Quote Post</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1041"><a href="https://chaai.qodeinteractive.com/enjoy-every-moment/"><span class="qodef-menu-item-text">Audio Post</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1044"><a href="https://chaai.qodeinteractive.com/fantastic-taste-of-tea-flavor/"><span class="qodef-menu-item-text">Galery Post</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1046"><a href="https://chaai.qodeinteractive.com/learn-more-about-tea/"><span class="qodef-menu-item-text">Video Post</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-2826"><a href="https://chaai.qodeinteractive.com/inspiration-in-tea/"><span class="qodef-menu-item-text">No Sidebar Post</span></a></li>
</ul>
</li>
</ul></div></div>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1501"><a href="https://chaai.qodeinteractive.com/landing/"><span class="qodef-menu-item-text">Landing</span></a></li>
</ul> </nav>
</header>
<div id="qodef-page-outer">
<div id="qodef-page-inner" class="qodef-content-full-width">
<main id="qodef-page-content" role="main">
<div id="qodef-404-page">
<h1 class="qodef-404-title">Error Page</h1>
<p class="qodef-404-text">The page you are looking for doesn&#039;t exist. It may have been moved or removed altogether. Please try searching for some other page, or return to the website&#039;s homepage to find what you&#039;re looking for.</p>
<div class="qodef-404-button">
<a class="qodef-shortcode qodef-m  qodef-button qodef-layout--filled  qodef-html--link" href="https://chaai.qodeinteractive.com/" target="_self"> <span class="qodef-m-text">Back to home</span></a> </div>
</div>
</main>
</div>
</div>
<footer id="qodef-page-footer" role="contentinfo">
<div id="qodef-page-footer-top-area" class="qodef-light-btt-skin">
<div id="qodef-page-footer-top-area-inner" class="qodef-content-grid">
<div class="qodef-grid qodef-layout--columns qodef-responsive--custom qodef-col-num--3 qodef-col-num--768--1 qodef-col-num--680--1 qodef-col-num--480--1 qodef-alignment--center">
<div class="qodef-grid-inner clear">
<div class="qodef-grid-item">
<div id="block-7" class="widget widget_block" data-area="qodef-footer-top-area-column-1"><h5>Get in Touch</h5>
<p> <a href="/cdn-cgi/l/email-protection#14777c75757d54657b70717d7a6071667577607d62713a777b79"><span class="__cf_email__" data-cfemail="b4d7dcd5d5ddf4c5dbd0d1dddac0d1c6d5d7c0ddc2d19ad7dbd9">[email&#160;protected]</span></a> <br>
<a href="https://www.google.com/maps/place/Z%C3%BCrich,+Switzerland/@47.3674155,8.5533229,16z/data=!4m5!3m4!1s0x47900b9749bea219:0xe66e8df1e71fdc03!8m2!3d47.3768866!4d8.541694" target="_blank" rel="noopener">Kalchbstrasse 4, 8038 Zürich</a><br>
<a href="tel:48933366641">+489 333 666 41</a></p></div> </div>
<div class="qodef-grid-item">
<div id="block-17" class="widget widget_block widget_media_image" data-area="qodef-footer-top-area-column-2">
<figure class="wp-block-image size-full"><a href="https://chaai.qodeinteractive.com/"><img loading="lazy" decoding="async" width="144" height="66" src="https://chaai.qodeinteractive.com/wp-content/uploads/2021/10/chaai-logo-futer-1.png" alt="j" class="wp-image-2773" /></a></figure>
</div><div id="chaai_core_social_icons_group-2" class="widget widget_chaai_core_social_icons_group" data-area="qodef-footer-top-area-column-2"> <div class="qodef-social-icons-group">
<span class="qodef-shortcode qodef-m  qodef-icon-holder  qodef-layout--normal qodef-enable-ring--yes"> <a itemprop="url" href="https://www.pinterest.com/qodeinteractive/" target="_blank"> <span class="qodef-icon-font-awesome fab fa-pinterest-p qodef-icon qodef-e" style="color: #ffffff"></span> </a> <svg class="qodef-svg-circle"><circle cx="50%" cy="50%" r="49%"></circle></svg> </span><span class="qodef-shortcode qodef-m  qodef-icon-holder  qodef-layout--normal qodef-enable-ring--yes"> <a itemprop="url" href="https://www.instagram.com/qodeinteractive/" target="_blank"> <span class="qodef-icon-font-awesome fab fa-instagram qodef-icon qodef-e" style="color: #ffffff"></span> </a> <svg class="qodef-svg-circle"><circle cx="50%" cy="50%" r="49%"></circle></svg> </span><span class="qodef-shortcode qodef-m  qodef-icon-holder  qodef-layout--normal qodef-enable-ring--yes"> <a itemprop="url" href="https://www.youtube.com/QodeInteractiveVideos" target="_blank"> <span class="qodef-icon-font-awesome fab fa-youtube qodef-icon qodef-e" style="color: #ffffff"></span> </a> <svg class="qodef-svg-circle"><circle cx="50%" cy="50%" r="49%"></circle></svg> </span><span class="qodef-shortcode qodef-m  qodef-icon-holder  qodef-layout--normal qodef-enable-ring--yes"> <a itemprop="url" href="https://www.facebook.com/QodeInteractive/" target="_blank"> <span class="qodef-icon-font-awesome fab fa-facebook-square qodef-icon qodef-e" style="color: #ffffff"></span> </a> <svg class="qodef-svg-circle"><circle cx="50%" cy="50%" r="49%"></circle></svg> </span> </div>
</div> </div>
<div class="qodef-grid-item">
<div id="block-9" class="widget widget_block" data-area="qodef-footer-top-area-column-3"><h5>Working Hours</h5>
<p>Monday/Friday 9:00-23:00</p>
<p>Saturday 10:00-21:00</p>
<p>Weekend Closed</p></div> </div>
</div>
</div>
</div>
</div>
<div id="qodef-page-footer-bottom-area">
<div id="qodef-page-footer-bottom-area-inner" class="qodef-content-full-width">
<div class="qodef-grid qodef-layout--columns qodef-responsive--custom qodef-col-num--1 qodef-gutter--no qodef-alignment--center">
<div class="qodef-grid-inner clear">
<div class="qodef-grid-item">
<div id="block-13" class="widget widget_block" data-area="qodef-footer-bottom-area-column-1"><p style="font-size:15px;">© 2021 <a href="https://qodeinteractive.com/" target="_blank" rel="nofollow noopener">Qode Interactive</a>, All Rights Reserved</p></div> </div>
</div>
</div>
</div>
</div>
</footer>
<a id="qodef-back-to-top" href="#">
<span class="qodef-back-to-top-icon">
<svg class="qodef-predefined" x="0px" y="0px" width="18.583px" height="61.502px" viewBox="2.75 4.499 18.583 61.502" enable-background="new 2.75 4.499 18.583 61.502" xml:space="preserve">
<line fill="none" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" x1="12" y1="65.248" x2="12" y2="5.248" />
<polyline fill="none" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" points="3.496,13.752   12,5.248 20.504,13.752 " />
</svg> </span>
</a>
</div>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="text/javascript">
			window.RS_MODULES = window.RS_MODULES || {};
			window.RS_MODULES.modules = window.RS_MODULES.modules || {};
			window.RS_MODULES.waiting = window.RS_MODULES.waiting || [];
			window.RS_MODULES.defered = false;
			window.RS_MODULES.moduleWaiting = window.RS_MODULES.moduleWaiting || {};
			window.RS_MODULES.type = 'compiled';
		</script>
<div class="rbt-toolbar" data-theme="Chaai" data-featured data-button-position="70%" data-button-horizontal="right" data-button-alt="no"></div>

<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KLJLSX7"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>

<script type="text/javascript">
var sbiajaxurl = "https://chaai.qodeinteractive.com/wp-admin/admin-ajax.php";
</script>
<script type="text/javascript">
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})();
	</script>
<link rel="stylesheet" id="perfect-scrollbar-css" href="https://chaai.qodeinteractive.com/wp-content/plugins/chaai-core/assets/plugins/perfect-scrollbar/perfect-scrollbar.css?ver=6.4.3" type="text/css" media="all" />
<link rel="stylesheet" id="rs-plugin-settings-css" href="https://chaai.qodeinteractive.com/wp-content/plugins/revslider/public/assets/css/rs6.css?ver=6.5.8" type="text/css" media="all" />
<style id="rs-plugin-settings-inline-css" type="text/css">
#rs-demo-id {}
</style>
<script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-includes/js/dist/vendor/wp-polyfill-inert.min.js?ver=3.1.2" id="wp-polyfill-inert-js"></script>
<script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-includes/js/dist/vendor/regenerator-runtime.min.js?ver=0.14.0" id="regenerator-runtime-js"></script>
<script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0" id="wp-polyfill-js"></script>
<script type="text/javascript" id="contact-form-7-js-extra">
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/chaai.qodeinteractive.com\/wp-json\/","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.5.1" id="contact-form-7-js"></script>
<script type="text/javascript" src="https://export.qodethemes.com/_toolbar/assets/js/rbt-modules.js?ver=6.4.3" id="rabbit_js-js"></script>
<script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.7.0-wc.5.8.1" id="jquery-blockui-js"></script>
<script type="text/javascript" id="wc-add-to-cart-js-extra">
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/chaai.qodeinteractive.com\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=5.8.1" id="wc-add-to-cart-js"></script>
<script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4-wc.5.8.1" id="js-cookie-js"></script>
<script type="text/javascript" id="woocommerce-js-extra">
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=5.8.1" id="woocommerce-js"></script>
<script type="text/javascript" id="wc-cart-fragments-js-extra">
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_10307a37c7262a1cdd118dbeee488cbb","fragment_name":"wc_fragments_10307a37c7262a1cdd118dbeee488cbb","request_timeout":"5000"};
/* ]]> */
</script>
<script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=5.8.1" id="wc-cart-fragments-js"></script>
<script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-includes/js/jquery/ui/core.min.js?ver=1.13.2" id="jquery-ui-core-js"></script>
<script type="text/javascript" id="qi-addons-for-elementor-script-js-extra">
/* <![CDATA[ */
var qodefQiAddonsGlobal = {"vars":{"adminBarHeight":0,"iconArrowLeft":"<svg  xmlns=\"http:\/\/www.w3.org\/2000\/svg\" xmlns:xlink=\"http:\/\/www.w3.org\/1999\/xlink\" x=\"0px\" y=\"0px\" viewBox=\"0 0 34.2 32.3\" xml:space=\"preserve\" style=\"stroke-width: 2;\"><line x1=\"0.5\" y1=\"16\" x2=\"33.5\" y2=\"16\"\/><line x1=\"0.3\" y1=\"16.5\" x2=\"16.2\" y2=\"0.7\"\/><line x1=\"0\" y1=\"15.4\" x2=\"16.2\" y2=\"31.6\"\/><\/svg>","iconArrowRight":"<svg  xmlns=\"http:\/\/www.w3.org\/2000\/svg\" xmlns:xlink=\"http:\/\/www.w3.org\/1999\/xlink\" x=\"0px\" y=\"0px\" viewBox=\"0 0 34.2 32.3\" xml:space=\"preserve\" style=\"stroke-width: 2;\"><line x1=\"0\" y1=\"16\" x2=\"33\" y2=\"16\"\/><line x1=\"17.3\" y1=\"0.7\" x2=\"33.2\" y2=\"16.5\"\/><line x1=\"17.3\" y1=\"31.6\" x2=\"33.5\" y2=\"15.4\"\/><\/svg>","iconClose":"<svg  xmlns=\"http:\/\/www.w3.org\/2000\/svg\" xmlns:xlink=\"http:\/\/www.w3.org\/1999\/xlink\" x=\"0px\" y=\"0px\" viewBox=\"0 0 9.1 9.1\" xml:space=\"preserve\"><g><path d=\"M8.5,0L9,0.6L5.1,4.5L9,8.5L8.5,9L4.5,5.1L0.6,9L0,8.5L4,4.5L0,0.6L0.6,0L4.5,4L8.5,0z\"\/><\/g><\/svg>"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/assets/js/main.min.js?ver=6.4.3" id="qi-addons-for-elementor-script-js"></script>
<script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-includes/js/hoverIntent.min.js?ver=1.10.2" id="hoverIntent-js"></script>
<script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-content/plugins/chaai-core/assets/plugins/modernizr/modernizr.js?ver=6.4.3" id="modernizr-js"></script>
<script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/inc/shortcodes/parallax-images/assets/js/plugins/jquery.parallax-scroll.js?ver=1" id="parallax-scroll-js"></script>
<script type="text/javascript" id="chaai-main-js-js-extra">
/* <![CDATA[ */
var qodefGlobal = {"vars":{"adminBarHeight":0,"iconArrowLeft":"<svg class=\"qodef-svg--slider-arrow-left\" x=\"0px\" y=\"0px\" width=\"24.83px\" height=\"18.58px\" viewBox=\"3.33 2.67 24.83 18.58\" enable-background=\"new 3.33 2.67 24.83 18.58\" xml:space=\"preserve\"><line fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" x1=\"27.25\" y1=\"12\" x2=\"4.25\" y2=\"12\"\/><polyline fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" points=\"12.75,20.5 4.25,12 12.75,3.5 \"\/><\/svg>","iconArrowRight":"<svg class=\"qodef-svg--slider-arrow-right\" x=\"0px\" y=\"0px\" width=\"24.83px\" height=\"18.58px\" viewBox=\"3.33 2.67 24.83 18.58\" enable-background=\"new 3.33 2.67 24.83 18.58\" xml:space=\"preserve\"><line fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" x1=\"4.25\" y1=\"12\" x2=\"27.25\" y2=\"12\"><\/line><polyline fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" points=\"18.75,3.5   27.25,12 18.75,20.5 \"\/><\/svg>","iconClose":"<svg class=\"qodef-svg--close\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\" xmlns:xlink=\"http:\/\/www.w3.org\/1999\/xlink\" width=\"32\" height=\"32\" viewBox=\"0 0 32 32\"><g><path d=\"M 10.050,23.95c 0.39,0.39, 1.024,0.39, 1.414,0L 17,18.414l 5.536,5.536c 0.39,0.39, 1.024,0.39, 1.414,0 c 0.39-0.39, 0.39-1.024,0-1.414L 18.414,17l 5.536-5.536c 0.39-0.39, 0.39-1.024,0-1.414c-0.39-0.39-1.024-0.39-1.414,0 L 17,15.586L 11.464,10.050c-0.39-0.39-1.024-0.39-1.414,0c-0.39,0.39-0.39,1.024,0,1.414L 15.586,17l-5.536,5.536 C 9.66,22.926, 9.66,23.56, 10.050,23.95z\"><\/path><\/g><\/svg>","qodefStickyHeaderScrollAmount":1000,"topAreaHeight":0,"restUrl":"https:\/\/chaai.qodeinteractive.com\/wp-json\/","restNonce":"4838b97125","paginationRestRoute":"chaai\/v1\/get-posts","headerHeight":106,"mobileHeaderHeight":70}};
/* ]]> */
</script>
<script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-content/themes/chaai/assets/js/main.min.js?ver=6.4.3" id="chaai-main-js-js"></script>
<script type="text/javascript" src="//maps.googleapis.com/maps/api/js?key=AIzaSyCkv67Ibrb52VxLOFXokU0QFOvh6hYwB4Y&amp;ver=6.4.3" id="google-map-api-js"></script>
<script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-includes/js/underscore.min.js?ver=1.13.4" id="underscore-js"></script>
<script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-content/plugins/chaai-core/inc/maps/assets/js/custom-marker.js?ver=6.4.3" id="chaai-core-map-custom-marker-js"></script>
<script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-content/plugins/chaai-core/inc/maps/assets/js/markerclusterer.js?ver=6.4.3" id="markerclusterer-js"></script>
<script type="text/javascript" id="chaai-core-google-map-js-extra">
/* <![CDATA[ */
var qodefMapsVariables = {"global":{"mapStyle":[{"featureType":"administrative.land_parcel","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"landscape.man_made","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"poi","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"road","elementType":"labels","stylers":[{"visibility":"simplified"},{"lightness":20}]},{"featureType":"road.highway","elementType":"geometry","stylers":[{"hue":"#f49935"}]},{"featureType":"road.highway","elementType":"labels","stylers":[{"visibility":"simplified"}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"hue":"#fad959"}]},{"featureType":"road.arterial","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"visibility":"simplified"}]},{"featureType":"road.local","elementType":"labels","stylers":[{"visibility":"simplified"}]},{"featureType":"transit","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"water","elementType":"all","stylers":[{"hue":"#a1cdfc"},{"saturation":30},{"lightness":49}]}],"mapZoom":12,"mapScrollable":false,"mapDraggable":true,"streetViewControl":true,"zoomControl":true,"mapTypeControl":true,"fullscreenControl":true,"geolocationTitle":"Your location is here"},"multiple":[]};
/* ]]> */
</script>
<script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-content/plugins/chaai-core/inc/maps/assets/js/google-map.js?ver=6.4.3" id="chaai-core-google-map-js"></script>
<script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-content/plugins/chaai-core/assets/js/chaai-core.min.js?ver=6.4.3" id="chaai-core-script-js"></script>
<script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-content/plugins/elementor/assets/lib/swiper/swiper.min.js?ver=5.3.6" id="swiper-js"></script>
<script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/select2/select2.full.min.js?ver=4.0.3-wc.5.8.1" id="select2-js"></script>
<script type="text/javascript" src="https://static.zdassets.com/ekr/snippet.js?key=af3078fd-a5ae-40da-bee0-e589b98c8603&ver=6.4.3" id="ze-snippet"></script><script type="text/javascript">
						zE(function(){
							$zopim(function(){
								var isChatEnabled = sessionStorage.getItem("qodeChatEnabled"),
									appearingTime = 15000;
								
								if(isChatEnabled !== "no" && window.innerWidth > 1024) {
									setTimeout(function(){
										$zopim.livechat.window.show();
										
										 $zopim.livechat.window.onHide(function(){
										    sessionStorage.setItem("qodeChatEnabled", "no");
										 });
									}, appearingTime);
								}
							});
						});
						</script><script type="text/javascript" src="https://chaai.qodeinteractive.com/wp-content/plugins/chaai-core/assets/plugins/perfect-scrollbar/perfect-scrollbar.jquery.min.js?ver=6.4.3" id="perfect-scrollbar-js"></script>
</body>
</html>
